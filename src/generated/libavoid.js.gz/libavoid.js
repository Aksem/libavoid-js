
var initAvoidModule = (() => {
  var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;
  
  return (
function(initAvoidModule) {
  initAvoidModule = initAvoidModule || {};


var a;
a || (a = typeof initAvoidModule !== 'undefined' ? initAvoidModule : {});
var aa, ba;
a.ready = new Promise(function(b, c) {
  aa = b;
  ba = c;
});
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VoidPtr___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_VoidPtr___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VoidPtr___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VoidPtr___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VoidPtr___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeImprover_HyperedgeImprover_0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_HyperedgeImprover_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeImprover_HyperedgeImprover_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_HyperedgeImprover_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeImprover_HyperedgeImprover_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeImprover_clear_0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_clear_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeImprover_clear_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_clear_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeImprover_clear_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeImprover_setRouter_1") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_setRouter_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeImprover_setRouter_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover_setRouter_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeImprover_setRouter_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeImprover___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeImprover___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeImprover___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeImprover___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_Box_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_Box_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_Box_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_Box_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_Box_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_length_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_length_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_length_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_length_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_length_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_width_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_width_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_width_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_width_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_width_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_height_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_height_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_height_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_height_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_height_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_get_min_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_get_min_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_get_min_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_get_min_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_get_min_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_set_min_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_set_min_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_set_min_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_set_min_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_set_min_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_get_max_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_get_max_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_get_max_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_get_max_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_get_max_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box_set_max_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Box_set_max_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box_set_max_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box_set_max_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box_set_max_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Box___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Box___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Box___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Box___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Box___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_clear_0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_clear_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_clear_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_clear_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_clear_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_empty_0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_empty_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_empty_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_empty_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_empty_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_size_0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_size_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_size_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_size_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_size_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_id_0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_id_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_id_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_at_1") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_at_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_at_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_at_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_at_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_boundingRectPolygon_0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_boundingRectPolygon_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_boundingRectPolygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_boundingRectPolygon_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_boundingRectPolygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_offsetBoundingBox_1") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_offsetBoundingBox_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_offsetBoundingBox_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_offsetBoundingBox_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_offsetBoundingBox_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface_offsetPolygon_1") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_offsetPolygon_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface_offsetPolygon_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface_offsetPolygon_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface_offsetPolygon_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_PolygonInterface___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_PolygonInterface___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_PolygonInterface___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_PolygonInterface___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_Polygon_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_Polygon_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_Polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_Polygon_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_Polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_Polygon_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_Polygon_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_Polygon_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_Polygon_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_Polygon_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_setPoint_2") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_setPoint_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_setPoint_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_setPoint_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_setPoint_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_size_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_size_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_size_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_size_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_size_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_get_ps_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_get_ps_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_get_ps_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_get_ps_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_get_ps_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon_set_ps_2") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon_set_ps_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon_set_ps_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon_set_ps_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon_set_ps_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Polygon___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Polygon___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Polygon___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Polygon___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Polygon___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_Point_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_Point_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_Point_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_Point_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_Point_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_Point_2") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_Point_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_Point_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_Point_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_Point_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_equal_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_equal_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_equal_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_equal_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_equal_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_get_x_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_get_x_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_get_x_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_get_x_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_get_x_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_set_x_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_set_x_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_set_x_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_set_x_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_set_x_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_get_y_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_get_y_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_get_y_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_get_y_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_get_y_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_set_y_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_set_y_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_set_y_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_set_y_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_set_y_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_get_id_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_get_id_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_get_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_get_id_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_get_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_set_id_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_set_id_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_set_id_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_set_id_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_set_id_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_get_vn_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_get_vn_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_get_vn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_get_vn_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_get_vn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point_set_vn_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Point_set_vn_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point_set_vn_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point_set_vn_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point_set_vn_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Point___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Point___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Point___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Point___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Point___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Rectangle_Rectangle_3") || (Object.defineProperty(a.ready, "_emscripten_bind_Rectangle_Rectangle_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Rectangle_Rectangle_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Rectangle_Rectangle_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Rectangle_Rectangle_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Rectangle___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Rectangle___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Rectangle___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Rectangle___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Rectangle___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeTreeNode___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeTreeNode___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeNode___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeTreeNode___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeTreeEdge___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeEdge___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeTreeEdge___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeTreeEdge___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeTreeEdge___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_AStarPath_AStarPath_0") || (Object.defineProperty(a.ready, "_emscripten_bind_AStarPath_AStarPath_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_AStarPath_AStarPath_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_AStarPath_AStarPath_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_AStarPath_AStarPath_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_AStarPath_search_4") || (Object.defineProperty(a.ready, "_emscripten_bind_AStarPath_search_4", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_AStarPath_search_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_AStarPath_search_4", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_AStarPath_search_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_AStarPath___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_AStarPath___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_AStarPath___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_AStarPath___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_AStarPath___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnEnd_ConnEnd_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnEnd_ConnEnd_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_2") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnEnd_ConnEnd_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd_ConnEnd_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnEnd_ConnEnd_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnEnd___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnEnd___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnEnd___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnEnd___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_2") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_ActionInfo_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_ActionInfo_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_3") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_ActionInfo_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_ActionInfo_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_4") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_4", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_ActionInfo_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_ActionInfo_4", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_ActionInfo_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_obstacle_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_obstacle_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_obstacle_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_obstacle_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_obstacle_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_shape_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_shape_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_shape_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_shape_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_shape_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_conn_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_conn_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_conn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_conn_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_conn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_junction_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_junction_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_junction_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_junction_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_junction_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_addConnEndUpdate_3") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_addConnEndUpdate_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_addConnEndUpdate_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_addConnEndUpdate_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_addConnEndUpdate_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_get_type_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_type_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_get_type_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_type_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_get_type_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_set_type_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_type_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_set_type_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_type_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_set_type_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_get_objPtr_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_objPtr_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_get_objPtr_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_objPtr_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_get_objPtr_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_set_objPtr_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_objPtr_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_set_objPtr_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_objPtr_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_set_objPtr_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_get_newPoly_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_newPoly_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_get_newPoly_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_newPoly_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_get_newPoly_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_set_newPoly_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_newPoly_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_set_newPoly_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_newPoly_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_set_newPoly_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_get_newPosition_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_newPosition_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_get_newPosition_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_newPosition_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_get_newPosition_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_set_newPosition_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_newPosition_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_set_newPosition_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_newPosition_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_set_newPosition_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_get_firstMove_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_firstMove_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_get_firstMove_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_get_firstMove_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_get_firstMove_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo_set_firstMove_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_firstMove_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo_set_firstMove_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo_set_firstMove_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo_set_firstMove_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ActionInfo___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ActionInfo___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ActionInfo___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ActionInfo___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_setConnectionCost_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_setConnectionCost_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_setConnectionCost_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_setConnectionCost_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_setConnectionCost_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_position_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_position_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_position_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_position_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_position_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_position_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_position_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_position_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_directions_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_directions_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_directions_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_directions_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_directions_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_setExclusive_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_setExclusive_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_setExclusive_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_setExclusive_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_setExclusive_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin_isExclusive_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_isExclusive_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin_isExclusive_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin_isExclusive_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin_isExclusive_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeConnectionPin___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeConnectionPin___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeConnectionPin___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeConnectionPin___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Obstacle_id_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_id_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Obstacle_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_id_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Obstacle_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Obstacle_polygon_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_polygon_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Obstacle_polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_polygon_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Obstacle_polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Obstacle_router_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_router_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Obstacle_router_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_router_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Obstacle_router_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Obstacle_position_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_position_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Obstacle_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Obstacle_position_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Obstacle_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Obstacle___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Obstacle___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Obstacle___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Obstacle___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Obstacle___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_2") || (Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_JunctionRef_JunctionRef_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_JunctionRef_JunctionRef_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_3") || (Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_JunctionRef_JunctionRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_JunctionRef_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_JunctionRef_JunctionRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_JunctionRef_position_0") || (Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_position_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_JunctionRef_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef_position_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_JunctionRef_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_JunctionRef___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_JunctionRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_JunctionRef___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_JunctionRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_2") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeRef_ShapeRef_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeRef_ShapeRef_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_3") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeRef_ShapeRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_ShapeRef_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeRef_ShapeRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeRef_polygon_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_polygon_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeRef_polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_polygon_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeRef_polygon_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeRef_position_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_position_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeRef_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef_position_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeRef_position_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ShapeRef___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ShapeRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ShapeRef___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ShapeRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_HyperedgeRerouter___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_HyperedgeRerouter___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_HyperedgeRerouter___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_HyperedgeRerouter___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertInf___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertInf___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertInf___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertInf___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertInf___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_VertID_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_VertID_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_VertID_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_VertID_2") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_VertID_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_VertID_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_VertID_3") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_VertID_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_VertID_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_VertID_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_objID_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_objID_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_objID_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_objID_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_objID_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_set_objID_1") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_objID_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_set_objID_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_objID_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_set_objID_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_vn_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_vn_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_vn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_vn_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_vn_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_set_vn_1") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_vn_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_set_vn_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_vn_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_set_vn_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_props_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_props_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_props_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_props_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_props_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_set_props_1") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_props_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_set_props_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_set_props_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_set_props_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_src_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_src_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_src_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_src_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_src_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_tar_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_tar_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_tar_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_tar_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_tar_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_PROP_ConnPoint_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnPoint_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_PROP_ConnPoint_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnPoint_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_PROP_ConnPoint_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_PROP_OrthShapeEdge_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_OrthShapeEdge_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_PROP_OrthShapeEdge_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_OrthShapeEdge_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_PROP_OrthShapeEdge_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_PROP_ConnectionPin_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnectionPin_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_PROP_ConnectionPin_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnectionPin_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_PROP_ConnectionPin_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_PROP_ConnCheckpoint_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnCheckpoint_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_PROP_ConnCheckpoint_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_ConnCheckpoint_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_PROP_ConnCheckpoint_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID_get_PROP_DummyPinHelper_0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_DummyPinHelper_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID_get_PROP_DummyPinHelper_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID_get_PROP_DummyPinHelper_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID_get_PROP_DummyPinHelper_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_VertID___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_VertID___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_VertID___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_VertID___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_VertID___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_MinimumTerminalSpanningTree___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_MinimumTerminalSpanningTree___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_MinimumTerminalSpanningTree___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_MinimumTerminalSpanningTree___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_MinimumTerminalSpanningTree___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Checkpoint_Checkpoint_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Checkpoint_Checkpoint_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Checkpoint_Checkpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Checkpoint_Checkpoint_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Checkpoint_Checkpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Checkpoint___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Checkpoint___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Checkpoint___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Checkpoint___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Checkpoint___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_ConnRef_3") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_ConnRef_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_ConnRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_ConnRef_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_ConnRef_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_ConnRef_4") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_ConnRef_4", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_ConnRef_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_ConnRef_4", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_ConnRef_4 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_id_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_id_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_id_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_id_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_setCallback_2") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setCallback_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_setCallback_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setCallback_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_setCallback_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_setSourceEndpoint_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setSourceEndpoint_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_setSourceEndpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setSourceEndpoint_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_setSourceEndpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_setDestEndpoint_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setDestEndpoint_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_setDestEndpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setDestEndpoint_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_setDestEndpoint_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_routingType_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_routingType_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_routingType_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_routingType_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_routingType_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_setRoutingType_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setRoutingType_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_setRoutingType_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setRoutingType_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_setRoutingType_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_displayRoute_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_displayRoute_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_displayRoute_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_displayRoute_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_displayRoute_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_setHateCrossings_1") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setHateCrossings_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_setHateCrossings_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_setHateCrossings_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_setHateCrossings_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef_doesHateCrossings_0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_doesHateCrossings_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef_doesHateCrossings_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef_doesHateCrossings_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef_doesHateCrossings_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_ConnRef___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_ConnRef___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_ConnRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_ConnRef___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_ConnRef___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_2") || (Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_EdgeInf_EdgeInf_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_EdgeInf_EdgeInf_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_3") || (Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_EdgeInf_EdgeInf_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf_EdgeInf_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_EdgeInf_EdgeInf_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_EdgeInf___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_EdgeInf___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_EdgeInf___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_EdgeInf___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_LineRep_get_begin_0") || (Object.defineProperty(a.ready, "_emscripten_bind_LineRep_get_begin_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_LineRep_get_begin_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_LineRep_get_begin_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_LineRep_get_begin_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_LineRep_set_begin_1") || (Object.defineProperty(a.ready, "_emscripten_bind_LineRep_set_begin_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_LineRep_set_begin_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_LineRep_set_begin_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_LineRep_set_begin_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_LineRep_get_end_0") || (Object.defineProperty(a.ready, "_emscripten_bind_LineRep_get_end_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_LineRep_get_end_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_LineRep_get_end_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_LineRep_get_end_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_LineRep_set_end_1") || (Object.defineProperty(a.ready, "_emscripten_bind_LineRep_set_end_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_LineRep_set_end_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_LineRep_set_end_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_LineRep_set_end_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_LineRep___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_LineRep___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_LineRep___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_LineRep___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_LineRep___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_Router_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_Router_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_Router_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_Router_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_Router_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_processTransaction_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_processTransaction_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_processTransaction_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_processTransaction_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_processTransaction_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_printInfo_0") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_printInfo_0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_printInfo_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_printInfo_0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_printInfo_0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_deleteConnector_1") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_deleteConnector_1", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_deleteConnector_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_deleteConnector_1", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_deleteConnector_1 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_moveShape_3") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_moveShape_3", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_moveShape_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_moveShape_3", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_moveShape_3 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_setRoutingParameter_2") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_setRoutingParameter_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_setRoutingParameter_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_setRoutingParameter_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_setRoutingParameter_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router_setRoutingOption_2") || (Object.defineProperty(a.ready, "_emscripten_bind_Router_setRoutingOption_2", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router_setRoutingOption_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router_setRoutingOption_2", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router_setRoutingOption_2 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_bind_Router___destroy___0") || (Object.defineProperty(a.ready, "_emscripten_bind_Router___destroy___0", {configurable:!0, get:function() {
  d("You are getting _emscripten_bind_Router___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_bind_Router___destroy___0", {configurable:!0, set:function() {
  d("You are setting _emscripten_bind_Router___destroy___0 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirNone") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirNone", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirNone on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirNone", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirNone on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirUp") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirUp", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirUp on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirUp", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirUp on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirDown") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirDown", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirDown on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirDown", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirDown on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirRight") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirRight", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirRight on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirRight", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirRight on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirAll") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirAll", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnDirFlag_ConnDirAll on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnDirFlag_ConnDirAll", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnDirFlag_ConnDirAll on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndPoint") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndPoint", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnEndType_ConnEndPoint on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndPoint", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnEndType_ConnEndPoint on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndShapePin") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndShapePin", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnEndType_ConnEndShapePin on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndShapePin", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnEndType_ConnEndShapePin on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndJunction") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndJunction", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnEndType_ConnEndJunction on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndJunction", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnEndType_ConnEndJunction on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndEmpty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndEmpty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnEndType_ConnEndEmpty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnEndType_ConnEndEmpty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnEndType_ConnEndEmpty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeMove") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeMove", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_ShapeMove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeMove", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_ShapeMove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeAdd") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeAdd", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_ShapeAdd on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeAdd", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_ShapeAdd on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeRemove") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeRemove", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_ShapeRemove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ShapeRemove", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_ShapeRemove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionMove") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionMove", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_JunctionMove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionMove", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_JunctionMove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionAdd") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionAdd", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_JunctionAdd on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionAdd", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_JunctionAdd on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionRemove") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionRemove", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_JunctionRemove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_JunctionRemove", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_JunctionRemove on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_ConnChange") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ConnChange", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_ConnChange on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ConnChange", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_ConnChange on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ActionType_ConnectionPinChange") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ConnectionPinChange", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ActionType_ConnectionPinChange on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ActionType_ConnectionPinChange", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ActionType_ConnectionPinChange on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270 on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_None") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_None", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnType_ConnType_None on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_None", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnType_ConnType_None on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_PolyLine") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_PolyLine", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnType_ConnType_PolyLine on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_PolyLine", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnType_ConnType_PolyLine on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_Orthogonal") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_Orthogonal", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_ConnType_ConnType_Orthogonal on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_ConnType_ConnType_Orthogonal", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_ConnType_ConnType_Orthogonal on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RouterFlag_PolyLineRouting") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RouterFlag_PolyLineRouting", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RouterFlag_PolyLineRouting on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RouterFlag_PolyLineRouting", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RouterFlag_PolyLineRouting on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RouterFlag_OrthogonalRouting") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RouterFlag_OrthogonalRouting", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RouterFlag_OrthogonalRouting on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RouterFlag_OrthogonalRouting", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RouterFlag_OrthogonalRouting on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_segmentPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_segmentPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_segmentPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_segmentPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_segmentPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_anglePenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_anglePenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_anglePenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_anglePenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_anglePenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_crossingPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_crossingPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_crossingPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_crossingPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_crossingPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint") || (Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint", {configurable:!0, get:function() {
  d("You are getting _emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "_emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint", {configurable:!0, set:function() {
  d("You are setting _emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "___stdio_exit") || (Object.defineProperty(a.ready, "___stdio_exit", {configurable:!0, get:function() {
  d("You are getting ___stdio_exit on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "___stdio_exit", {configurable:!0, set:function() {
  d("You are setting ___stdio_exit on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
Object.getOwnPropertyDescriptor(a.ready, "onRuntimeInitialized") || (Object.defineProperty(a.ready, "onRuntimeInitialized", {configurable:!0, get:function() {
  d("You are getting onRuntimeInitialized on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}), Object.defineProperty(a.ready, "onRuntimeInitialized", {configurable:!0, set:function() {
  d("You are setting onRuntimeInitialized on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js");
}}));
var ca = Object.assign({}, a), da = "./this.program";
if (a.ENVIRONMENT) {
  throw Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -s ENVIRONMENT=web or -s ENVIRONMENT=node)");
}
var fa = "";
"undefined" != typeof document && document.currentScript && (fa = document.currentScript.src);
_scriptDir && (fa = _scriptDir);
0 !== fa.indexOf("blob:") ? fa = fa.substr(0, fa.replace(/[?#].*/, "").lastIndexOf("/") + 1) : fa = "";
if ("object" != typeof window && "function" != typeof importScripts) {
  throw Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
}
var ha = a.print || console.log.bind(console), f = a.printErr || console.warn.bind(console);
Object.assign(a, ca);
ca = null;
Object.getOwnPropertyDescriptor(a, "fetchSettings") && d("`Module.fetchSettings` was supplied but `fetchSettings` not included in INCOMING_MODULE_JS_API");
g("arguments", "arguments_");
a.thisProgram && (da = a.thisProgram);
g("thisProgram", "thisProgram");
g("quit", "quit_");
p("undefined" == typeof a.memoryInitializerPrefixURL, "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
p("undefined" == typeof a.pthreadMainPrefixURL, "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
p("undefined" == typeof a.cdInitializerPrefixURL, "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
p("undefined" == typeof a.filePackagePrefixURL, "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
p("undefined" == typeof a.read, "Module.read option was removed (modify read_ in JS)");
p("undefined" == typeof a.readAsync, "Module.readAsync option was removed (modify readAsync in JS)");
p("undefined" == typeof a.readBinary, "Module.readBinary option was removed (modify readBinary in JS)");
p("undefined" == typeof a.setWindowTitle, "Module.setWindowTitle option was removed (modify setWindowTitle in JS)");
p("undefined" == typeof a.TOTAL_MEMORY, "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
g("read", "read_");
g("readAsync", "readAsync");
g("readBinary", "readBinary");
g("setWindowTitle", "setWindowTitle");
p(!0, "worker environment detected but not enabled at build time.  Add 'worker' to `-s ENVIRONMENT` to enable.");
p(!0, "node environment detected but not enabled at build time.  Add 'node' to `-s ENVIRONMENT` to enable.");
p(!0, "shell environment detected but not enabled at build time.  Add 'shell' to `-s ENVIRONMENT` to enable.");
function ia(b) {
  ja || (ja = {});
  ja[b] || (ja[b] = 1, f(b));
}
var ja, ka = [], la;
function g(b, c) {
  Object.getOwnPropertyDescriptor(a, b) || Object.defineProperty(a, b, {configurable:!0, get:function() {
    d("Module." + b + " has been replaced with plain " + c + " (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)");
  }});
}
function ma(b, c) {
  b = "'" + b + "' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the FAQ)";
  c && (b += ". Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you");
  return b;
}
function na(b) {
  Object.getOwnPropertyDescriptor(a, b) || Object.defineProperty(a, b, {configurable:!0, get:function() {
    d(ma(b, !1));
  }});
}
function q(b, c) {
  Object.getOwnPropertyDescriptor(a, b) || (a[b] = () => d(ma(b, c)));
}
var r = 0, oa;
a.wasmBinary && (oa = a.wasmBinary);
g("wasmBinary", "wasmBinary");
var noExitRuntime = a.noExitRuntime || !0;
g("noExitRuntime", "noExitRuntime");
"object" != typeof WebAssembly && d("no native wasm support detected");
var pa, qa = !1;
function p(b, c) {
  b || d("Assertion failed" + (c ? ": " + c : ""));
}
var ra = "undefined" != typeof TextDecoder ? new TextDecoder("utf8") : void 0;
function sa(b, c, e) {
  var h = c + e;
  for (e = c; b[e] && !(e >= h);) {
    ++e;
  }
  if (16 < e - c && b.buffer && ra) {
    return ra.decode(b.subarray(c, e));
  }
  for (h = ""; c < e;) {
    var k = b[c++];
    if (k & 128) {
      var l = b[c++] & 63;
      if (192 == (k & 224)) {
        h += String.fromCharCode((k & 31) << 6 | l);
      } else {
        var n = b[c++] & 63;
        224 == (k & 240) ? k = (k & 15) << 12 | l << 6 | n : (240 != (k & 248) && ia("Invalid UTF-8 leading byte 0x" + k.toString(16) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!"), k = (k & 7) << 18 | l << 12 | n << 6 | b[c++] & 63);
        65536 > k ? h += String.fromCharCode(k) : (k -= 65536, h += String.fromCharCode(55296 | k >> 10, 56320 | k & 1023));
      }
    } else {
      h += String.fromCharCode(k);
    }
  }
  return h;
}
function ta(b) {
  return b ? sa(ua, b, void 0) : "";
}
"undefined" != typeof TextDecoder && new TextDecoder("utf-16le");
function wa(b, c) {
  p(0 <= b.length, "writeArrayToMemory array must have a length (should be an array or typed array)");
  xa.set(b, c);
}
var ya, xa, ua, u, za;
function Aa() {
  var b = pa.buffer;
  ya = b;
  a.HEAP8 = xa = new Int8Array(b);
  a.HEAP16 = new Int16Array(b);
  a.HEAP32 = u = new Int32Array(b);
  a.HEAPU8 = ua = new Uint8Array(b);
  a.HEAPU16 = new Uint16Array(b);
  a.HEAPU32 = za = new Uint32Array(b);
  a.HEAPF32 = new Float32Array(b);
  a.HEAPF64 = new Float64Array(b);
}
a.TOTAL_STACK && p(5242880 === a.TOTAL_STACK, "the stack size can no longer be determined at runtime");
var Ba = a.INITIAL_MEMORY || 16777216;
g("INITIAL_MEMORY", "INITIAL_MEMORY");
p(5242880 <= Ba, "INITIAL_MEMORY should be larger than TOTAL_STACK, was " + Ba + "! (TOTAL_STACK=5242880)");
p("undefined" != typeof Int32Array && "undefined" !== typeof Float64Array && void 0 != Int32Array.prototype.subarray && void 0 != Int32Array.prototype.set, "JS engine does not provide full typed array support");
p(!a.wasmMemory, "Use of `wasmMemory` detected.  Use -s IMPORTED_MEMORY to define wasmMemory externally");
p(16777216 == Ba, "Detected runtime INITIAL_MEMORY setting.  Use -s IMPORTED_MEMORY to define wasmMemory dynamically");
var Ca;
function Da() {
  var b = Ea();
  p(0 == (b & 3));
  u[b >> 2] = 34821223;
  u[b + 4 >> 2] = 2310721022;
  u[0] = 1668509029;
}
function Fa() {
  if (!qa) {
    var b = Ea(), c = za[b >> 2];
    b = za[b + 4 >> 2];
    34821223 == c && 2310721022 == b || d("Stack overflow! Stack cookie has been overwritten, expected hex dwords 0x89BACDFE and 0x2135467, but received 0x" + b.toString(16) + " 0x" + c.toString(16));
    1668509029 !== u[0] && d("Runtime error: The application has corrupted its heap memory area (address zero)!");
  }
}
var Ga = new Int16Array(1), Ha = new Int8Array(Ga.buffer);
Ga[0] = 25459;
if (115 !== Ha[0] || 99 !== Ha[1]) {
  throw "Runtime error: expected the system to be little-endian! (Run with -s SUPPORT_BIG_ENDIAN=1 to bypass)";
}
var Ia = [], Ja = [], Ka = [], La = !1;
function Ma() {
  var b = a.preRun.shift();
  Ia.unshift(b);
}
p(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
p(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
p(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
p(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
var Na = 0, Oa = null, Pa = null, Qa = {};
function Ra() {
  Na++;
  a.monitorRunDependencies && a.monitorRunDependencies(Na);
  p(!Qa["wasm-instantiate"]);
  Qa["wasm-instantiate"] = 1;
  null === Oa && "undefined" != typeof setInterval && (Oa = setInterval(function() {
    if (qa) {
      clearInterval(Oa), Oa = null;
    } else {
      var b = !1, c;
      for (c in Qa) {
        b || (b = !0, f("still waiting on run dependencies:")), f("dependency: " + c);
      }
      b && f("(end of list)");
    }
  }, 10000));
}
a.preloadedImages = {};
a.preloadedAudios = {};
function d(b) {
  if (a.onAbort) {
    a.onAbort(b);
  }
  b = "Aborted(" + b + ")";
  f(b);
  qa = !0;
  b = new WebAssembly.RuntimeError(b);
  ba(b);
  throw b;
}
function Sa() {
  d("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with  -s FORCE_FILESYSTEM=1");
}
a.FS_createDataFile = function() {
  Sa();
};
a.FS_createPreloadedFile = function() {
  Sa();
};
function Ta() {
  return v.startsWith("data:application/octet-stream;base64,");
}
function w(b) {
  return function() {
    var c = a.asm;
    p(La, "native function `" + b + "` called before runtime initialization");
    c[b] || p(c[b], "exported native function `" + b + "` not found");
    return c[b].apply(null, arguments);
  };
}
var v;
v = "libavoid.wasm";
if (!Ta()) {
  var Ua = v;
  v = a.locateFile ? a.locateFile(Ua, fa) : fa + Ua;
}
function Va() {
  var b = v;
  try {
    if (b == v && oa) {
      return new Uint8Array(oa);
    }
    throw "both async and sync fetching of the wasm failed";
  } catch (c) {
    d(c);
  }
}
function Wa() {
  return oa || "function" != typeof fetch ? Promise.resolve().then(function() {
    return Va();
  }) : fetch(v, {credentials:"same-origin"}).then(function(b) {
    if (!b.ok) {
      throw "failed to load wasm binary file at '" + v + "'";
    }
    return b.arrayBuffer();
  }).catch(function() {
    return Va();
  });
}
function Xa(b) {
  for (; 0 < b.length;) {
    var c = b.shift();
    if ("function" == typeof c) {
      c(a);
    } else {
      var e = c.Ka;
      "number" == typeof e ? void 0 === c.H ? x(e)() : x(e)(c.H) : e(void 0 === c.H ? null : c.H);
    }
  }
}
var Ya = [];
function x(b) {
  var c = Ya[b];
  c || (b >= Ya.length && (Ya.length = b + 1), Ya[b] = c = Ca.get(b));
  p(Ca.get(b) == c, "JavaScript-side Wasm function table mirror is out of date!");
  return c;
}
function Za(b) {
  this.P = b;
  this.g = b - 16;
  this.M = function(c) {
    u[this.g + 4 >> 2] = c;
  };
  this.A = function() {
    return u[this.g + 4 >> 2];
  };
  this.C = function(c) {
    u[this.g + 8 >> 2] = c;
  };
  this.aa = function() {
    return u[this.g + 8 >> 2];
  };
  this.D = function() {
    u[this.g >> 2] = 0;
  };
  this.K = function(c) {
    xa[this.g + 12 >> 0] = c ? 1 : 0;
  };
  this.$ = function() {
    return 0 != xa[this.g + 12 >> 0];
  };
  this.L = function(c) {
    xa[this.g + 13 >> 0] = c ? 1 : 0;
  };
  this.R = function() {
    return 0 != xa[this.g + 13 >> 0];
  };
  this.u = function(c, e) {
    this.M(c);
    this.C(e);
    this.D();
    this.K(!1);
    this.L(!1);
  };
  this.T = function() {
    u[this.g >> 2] += 1;
  };
  this.ra = function() {
    var c = u[this.g >> 2];
    u[this.g >> 2] = c - 1;
    p(0 < c);
    return 1 === c;
  };
}
function $a(b) {
  this.I = function() {
    ab(this.g);
    this.g = 0;
  };
  this.S = function(c) {
    u[this.g >> 2] = c;
  };
  this.v = function() {
    return u[this.g >> 2];
  };
  this.u = function(c) {
    u[this.g + 4 >> 2] = c;
  };
  this.C = function() {
    return this.g + 4;
  };
  this.qa = function() {
    return u[this.g + 4 >> 2];
  };
  this.D = function() {
    if (bb(this.B().A())) {
      return u[this.v() >> 2];
    }
    var c = this.qa();
    return 0 !== c ? c : this.v();
  };
  this.B = function() {
    return new Za(this.v());
  };
  void 0 === b ? (this.g = cb(8), this.u(0)) : this.g = b;
}
var db = [], eb = 0, fb = 0;
function gb(b) {
  try {
    return ab((new Za(b)).g);
  } catch (c) {
    f("exception during cxa_free_exception: " + c);
  }
}
var hb = {};
function ib() {
  if (!jb) {
    var b = {USER:"web_user", LOGNAME:"web_user", PATH:"/", PWD:"/", HOME:"/home/web_user", LANG:("object" == typeof navigator && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8", _:da || "./this.program"}, c;
    for (c in hb) {
      void 0 === hb[c] ? delete b[c] : b[c] = hb[c];
    }
    var e = [];
    for (c in b) {
      e.push(c + "=" + b[c]);
    }
    jb = e;
  }
  return jb;
}
var jb, kb = [null, [], []];
function lb(b) {
  return 0 === b % 4 && (0 !== b % 100 || 0 === b % 400);
}
var mb = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], nb = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function ob(b, c, e, h) {
  function k(m, D, I) {
    for (m = "number" == typeof m ? m.toString() : m || ""; m.length < D;) {
      m = I[0] + m;
    }
    return m;
  }
  function l(m, D) {
    return k(m, D, "0");
  }
  function n(m, D) {
    function I(va) {
      return 0 > va ? -1 : 0 < va ? 1 : 0;
    }
    var ea;
    0 === (ea = I(m.getFullYear() - D.getFullYear())) && 0 === (ea = I(m.getMonth() - D.getMonth())) && (ea = I(m.getDate() - D.getDate()));
    return ea;
  }
  function t(m) {
    switch(m.getDay()) {
      case 0:
        return new Date(m.getFullYear() - 1, 11, 29);
      case 1:
        return m;
      case 2:
        return new Date(m.getFullYear(), 0, 3);
      case 3:
        return new Date(m.getFullYear(), 0, 2);
      case 4:
        return new Date(m.getFullYear(), 0, 1);
      case 5:
        return new Date(m.getFullYear() - 1, 11, 31);
      case 6:
        return new Date(m.getFullYear() - 1, 11, 30);
    }
  }
  function F(m) {
    var D = m.o;
    for (m = new Date((new Date(m.s + 1900, 0, 1)).getTime()); 0 < D;) {
      var I = m.getMonth(), ea = (lb(m.getFullYear()) ? mb : nb)[I];
      if (D > ea - m.getDate()) {
        D -= ea - m.getDate() + 1, m.setDate(1), 11 > I ? m.setMonth(I + 1) : (m.setMonth(0), m.setFullYear(m.getFullYear() + 1));
      } else {
        m.setDate(m.getDate() + D);
        break;
      }
    }
    I = new Date(m.getFullYear() + 1, 0, 4);
    D = t(new Date(m.getFullYear(), 0, 4));
    I = t(I);
    return 0 >= n(D, m) ? 0 >= n(I, m) ? m.getFullYear() + 1 : m.getFullYear() : m.getFullYear() - 1;
  }
  var B = u[h + 40 >> 2];
  h = {Ia:u[h >> 2], Ha:u[h + 4 >> 2], F:u[h + 8 >> 2], O:u[h + 12 >> 2], G:u[h + 16 >> 2], s:u[h + 20 >> 2], m:u[h + 24 >> 2], o:u[h + 28 >> 2], La:u[h + 32 >> 2], Ga:u[h + 36 >> 2], Ja:B ? ta(B) : ""};
  e = ta(e);
  B = {"%c":"%a %b %d %H:%M:%S %Y", "%D":"%m/%d/%y", "%F":"%Y-%m-%d", "%h":"%b", "%r":"%I:%M:%S %p", "%R":"%H:%M", "%T":"%H:%M:%S", "%x":"%m/%d/%y", "%X":"%H:%M:%S", "%Ec":"%c", "%EC":"%C", "%Ex":"%m/%d/%y", "%EX":"%H:%M:%S", "%Ey":"%y", "%EY":"%Y", "%Od":"%d", "%Oe":"%e", "%OH":"%H", "%OI":"%I", "%Om":"%m", "%OM":"%M", "%OS":"%S", "%Ou":"%u", "%OU":"%U", "%OV":"%V", "%Ow":"%w", "%OW":"%W", "%Oy":"%y",};
  for (var G in B) {
    e = e.replace(new RegExp(G, "g"), B[G]);
  }
  var N = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "), Z = "January February March April May June July August September October November December".split(" ");
  B = {"%a":function(m) {
    return N[m.m].substring(0, 3);
  }, "%A":function(m) {
    return N[m.m];
  }, "%b":function(m) {
    return Z[m.G].substring(0, 3);
  }, "%B":function(m) {
    return Z[m.G];
  }, "%C":function(m) {
    return l((m.s + 1900) / 100 | 0, 2);
  }, "%d":function(m) {
    return l(m.O, 2);
  }, "%e":function(m) {
    return k(m.O, 2, " ");
  }, "%g":function(m) {
    return F(m).toString().substring(2);
  }, "%G":function(m) {
    return F(m);
  }, "%H":function(m) {
    return l(m.F, 2);
  }, "%I":function(m) {
    m = m.F;
    0 == m ? m = 12 : 12 < m && (m -= 12);
    return l(m, 2);
  }, "%j":function(m) {
    for (var D = 0, I = 0; I <= m.G - 1; D += (lb(m.s + 1900) ? mb : nb)[I++]) {
    }
    return l(m.O + D, 3);
  }, "%m":function(m) {
    return l(m.G + 1, 2);
  }, "%M":function(m) {
    return l(m.Ha, 2);
  }, "%n":function() {
    return "\n";
  }, "%p":function(m) {
    return 0 <= m.F && 12 > m.F ? "AM" : "PM";
  }, "%S":function(m) {
    return l(m.Ia, 2);
  }, "%t":function() {
    return "\t";
  }, "%u":function(m) {
    return m.m || 7;
  }, "%U":function(m) {
    return l(Math.floor((m.o + 7 - m.m) / 7), 2);
  }, "%V":function(m) {
    var D = Math.floor((m.o + 7 - (m.m + 6) % 7) / 7);
    2 >= (m.m + 371 - m.o - 2) % 7 && D++;
    if (D) {
      53 == D && (I = (m.m + 371 - m.o) % 7, 4 == I || 3 == I && lb(m.s) || (D = 1));
    } else {
      D = 52;
      var I = (m.m + 7 - m.o - 1) % 7;
      (4 == I || 5 == I && lb(m.s % 400 - 1)) && D++;
    }
    return l(D, 2);
  }, "%w":function(m) {
    return m.m;
  }, "%W":function(m) {
    return l(Math.floor((m.o + 7 - (m.m + 6) % 7) / 7), 2);
  }, "%y":function(m) {
    return (m.s + 1900).toString().substring(2);
  }, "%Y":function(m) {
    return m.s + 1900;
  }, "%z":function(m) {
    m = m.Ga;
    var D = 0 <= m;
    m = Math.abs(m) / 60;
    return (D ? "+" : "-") + String("0000" + (m / 60 * 100 + m % 60)).slice(-4);
  }, "%Z":function(m) {
    return m.Ja;
  }, "%%":function() {
    return "%";
  }};
  e = e.replace(/%%/g, "\x00\x00");
  for (G in B) {
    e.includes(G) && (e = e.replace(new RegExp(G, "g"), B[G](h)));
  }
  e = e.replace(/\0\0/g, "%");
  G = pb(e);
  if (G.length > c) {
    return 0;
  }
  wa(G, b);
  return G.length - 1;
}
function pb(b) {
  for (var c = 0, e = 0; e < b.length; ++e) {
    var h = b.charCodeAt(e);
    55296 <= h && 57343 >= h && (h = 65536 + ((h & 1023) << 10) | b.charCodeAt(++e) & 1023);
    127 >= h ? ++c : c = 2047 >= h ? c + 2 : 65535 >= h ? c + 3 : c + 4;
  }
  c = Array(c + 1);
  h = c.length;
  e = 0;
  if (0 < h) {
    h = e + h - 1;
    for (var k = 0; k < b.length; ++k) {
      var l = b.charCodeAt(k);
      if (55296 <= l && 57343 >= l) {
        var n = b.charCodeAt(++k);
        l = 65536 + ((l & 1023) << 10) | n & 1023;
      }
      if (127 >= l) {
        if (e >= h) {
          break;
        }
        c[e++] = l;
      } else {
        if (2047 >= l) {
          if (e + 1 >= h) {
            break;
          }
          c[e++] = 192 | l >> 6;
        } else {
          if (65535 >= l) {
            if (e + 2 >= h) {
              break;
            }
            c[e++] = 224 | l >> 12;
          } else {
            if (e + 3 >= h) {
              break;
            }
            1114111 < l && ia("Invalid Unicode code point 0x" + l.toString(16) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
            c[e++] = 240 | l >> 18;
            c[e++] = 128 | l >> 12 & 63;
          }
          c[e++] = 128 | l >> 6 & 63;
        }
        c[e++] = 128 | l & 63;
      }
    }
    c[e] = 0;
  }
  return c;
}
var ac = {__assert_fail:function(b, c, e, h) {
  d("Assertion failed: " + ta(b) + ", at: " + [c ? ta(c) : "unknown filename", e, h ? ta(h) : "unknown function"]);
}, __cxa_allocate_exception:function(b) {
  return cb(b + 16) + 16;
}, __cxa_begin_catch:function(b) {
  b = new $a(b);
  var c = b.B();
  c.$() || (c.K(!0), eb--);
  c.L(!1);
  db.push(b);
  c.T();
  return b.D();
}, __cxa_end_catch:function() {
  y(0);
  p(0 < db.length);
  var b = db.pop(), c = b.B();
  if (c.ra() && !c.R()) {
    var e = c.aa();
    e && x(e)(c.P);
    gb(c.P);
  }
  b.I();
  fb = 0;
}, __cxa_find_matching_catch_2:function() {
  var b = fb;
  if (!b) {
    return r = 0;
  }
  var c = (new Za(b)).A(), e = new $a();
  e.S(b);
  e.u(b);
  if (!c) {
    return r = 0, e.g | 0;
  }
  b = Array.prototype.slice.call(arguments);
  for (var h = 0; h < b.length; h++) {
    var k = b[h];
    if (0 === k || k === c) {
      break;
    }
    if (qb(k, c, e.C())) {
      return r = k, e.g | 0;
    }
  }
  r = c;
  return e.g | 0;
}, __cxa_find_matching_catch_3:function() {
  var b = fb;
  if (!b) {
    return r = 0;
  }
  var c = (new Za(b)).A(), e = new $a();
  e.S(b);
  e.u(b);
  if (!c) {
    return r = 0, e.g | 0;
  }
  b = Array.prototype.slice.call(arguments);
  for (var h = 0; h < b.length; h++) {
    var k = b[h];
    if (0 === k || k === c) {
      break;
    }
    if (qb(k, c, e.C())) {
      return r = k, e.g | 0;
    }
  }
  r = c;
  return e.g | 0;
}, __cxa_free_exception:gb, __cxa_get_exception_ptr:function(b) {
  return (new $a(b)).D();
}, __cxa_rethrow:function() {
  var b = db.pop();
  b || d("no exception to throw");
  var c = b.B(), e = b.v();
  c.R() ? b.I() : (db.push(b), c.L(!0), c.K(!1), eb++);
  fb = e;
  throw e;
}, __cxa_throw:function(b, c, e) {
  (new Za(b)).u(c, e);
  fb = b;
  eb++;
  throw b;
}, __cxa_uncaught_exceptions:function() {
  return eb;
}, __resumeException:function(b) {
  b = new $a(b);
  var c = b.v();
  fb || (fb = c);
  b.I();
  throw c;
}, _emscripten_date_now:function() {
  return Date.now();
}, abort:function() {
  d("native code called abort()");
}, array_bounds_check_error:function(b, c) {
  throw "Array index " + b + " out of bounds: [0," + c + ")";
}, emscripten_memcpy_big:function(b, c, e) {
  ua.copyWithin(b, c, c + e);
}, emscripten_resize_heap:function(b) {
  var c = ua.length;
  b >>>= 0;
  p(b > c);
  if (2147483648 < b) {
    return f("Cannot enlarge memory, asked to go up to " + b + " bytes, but the limit is 2147483648 bytes!"), !1;
  }
  for (var e = 1; 4 >= e; e *= 2) {
    var h = c * (1 + 0.2 / e);
    h = Math.min(h, b + 100663296);
    var k = Math;
    h = Math.max(b, h);
    k = k.min.call(k, 2147483648, h + (65536 - h % 65536) % 65536);
    a: {
      h = k;
      try {
        pa.grow(h - ya.byteLength + 65535 >>> 16);
        Aa();
        var l = 1;
        break a;
      } catch (n) {
        f("emscripten_realloc_buffer: Attempted to grow heap from " + ya.byteLength + " bytes to " + h + " bytes, but got error: " + n);
      }
      l = void 0;
    }
    if (l) {
      return !0;
    }
  }
  f("Failed to grow the heap from " + c + " bytes to " + k + " bytes, not enough memory!");
  return !1;
}, environ_get:function(b, c) {
  var e = 0;
  ib().forEach(function(h, k) {
    var l = c + e;
    k = u[b + 4 * k >> 2] = l;
    for (l = 0; l < h.length; ++l) {
      p(h.charCodeAt(l) === (h.charCodeAt(l) & 255)), xa[k++ >> 0] = h.charCodeAt(l);
    }
    xa[k >> 0] = 0;
    e += h.length + 1;
  });
  return 0;
}, environ_sizes_get:function(b, c) {
  var e = ib();
  u[b >> 2] = e.length;
  var h = 0;
  e.forEach(function(k) {
    h += k.length + 1;
  });
  u[c >> 2] = h;
  return 0;
}, fd_close:function() {
  d("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
  return 0;
}, fd_seek:function() {
  d("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
}, fd_write:function(b, c, e, h) {
  for (var k = 0, l = 0; l < e; l++) {
    var n = u[c >> 2], t = u[c + 4 >> 2];
    c += 8;
    for (var F = 0; F < t; F++) {
      var B = b, G = ua[n + F], N = kb[B];
      p(N);
      0 === G || 10 === G ? ((1 === B ? ha : f)(sa(N, 0)), N.length = 0) : N.push(G);
    }
    k += t;
  }
  u[h >> 2] = k;
  return 0;
}, getTempRet0:function() {
  return r;
}, invoke_di:rb, invoke_didiii:sb, invoke_dii:tb, invoke_diii:ub, invoke_diiii:vb, invoke_i:wb, invoke_ii:xb, invoke_iid:yb, invoke_iii:zb, invoke_iiid:Ab, invoke_iiidd:Bb, invoke_iiii:Cb, invoke_iiiid:Db, invoke_iiiidddi:Eb, invoke_iiiiddidi:Fb, invoke_iiiii:Gb, invoke_iiiiid:Hb, invoke_iiiiii:Ib, invoke_iiiiiii:Jb, invoke_iiiiiiii:Kb, invoke_iiiiiiiidd:Lb, invoke_iiiiiiiiiiii:Mb, invoke_iiij:Nb, invoke_v:Ob, invoke_vi:Pb, invoke_vid:Qb, invoke_vidd:Rb, invoke_vii:Sb, invoke_viid:Tb, invoke_viii:Ub, 
invoke_viiid:Vb, invoke_viiii:Wb, invoke_viiiii:Xb, invoke_viiiiiii:Yb, invoke_viiiiiiiiii:Zb, invoke_viiiiiiiiiiiiiii:$b, llvm_eh_typeid_for:function(b) {
  return b;
}, setTempRet0:function(b) {
  r = b;
}, strftime_l:function(b, c, e, h) {
  return ob(b, c, e, h);
}};
(function() {
  function b(l) {
    a.asm = l.exports;
    pa = a.asm.memory;
    p(pa, "memory not found in wasm exports");
    Aa();
    Ca = a.asm.__indirect_function_table;
    p(Ca, "table not found in wasm exports");
    Ja.unshift(a.asm.__wasm_call_ctors);
    Na--;
    a.monitorRunDependencies && a.monitorRunDependencies(Na);
    p(Qa["wasm-instantiate"]);
    delete Qa["wasm-instantiate"];
    0 == Na && (null !== Oa && (clearInterval(Oa), Oa = null), Pa && (l = Pa, Pa = null, l()));
  }
  function c(l) {
    p(a === k, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
    k = null;
    b(l.instance);
  }
  function e(l) {
    return Wa().then(function(n) {
      return WebAssembly.instantiate(n, h);
    }).then(function(n) {
      return n;
    }).then(l, function(n) {
      f("failed to asynchronously prepare wasm: " + n);
      v.startsWith("file://") && f("warning: Loading from a file URI (" + v + ") is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing");
      d(n);
    });
  }
  var h = {env:ac, wasi_snapshot_preview1:ac,};
  Ra();
  var k = a;
  if (a.instantiateWasm) {
    try {
      return a.instantiateWasm(h, b);
    } catch (l) {
      return f("Module.instantiateWasm callback failed with error: " + l), !1;
    }
  }
  (function() {
    return oa || "function" != typeof WebAssembly.instantiateStreaming || Ta() || "function" != typeof fetch ? e(c) : fetch(v, {credentials:"same-origin"}).then(function(l) {
      return WebAssembly.instantiateStreaming(l, h).then(c, function(n) {
        f("wasm streaming compile failed: " + n);
        f("falling back to ArrayBuffer instantiation");
        return e(c);
      });
    });
  })().catch(ba);
  return {};
})();
a.___wasm_call_ctors = w("__wasm_call_ctors");
var cb = a._malloc = w("malloc"), ab = a._free = w("free"), bc = a._emscripten_bind_VoidPtr___destroy___0 = w("emscripten_bind_VoidPtr___destroy___0"), cc = a._emscripten_bind_HyperedgeImprover_HyperedgeImprover_0 = w("emscripten_bind_HyperedgeImprover_HyperedgeImprover_0"), dc = a._emscripten_bind_HyperedgeImprover_clear_0 = w("emscripten_bind_HyperedgeImprover_clear_0"), ec = a._emscripten_bind_HyperedgeImprover_setRouter_1 = w("emscripten_bind_HyperedgeImprover_setRouter_1"), fc = a._emscripten_bind_HyperedgeImprover___destroy___0 = 
w("emscripten_bind_HyperedgeImprover___destroy___0"), gc = a._emscripten_bind_Box_Box_0 = w("emscripten_bind_Box_Box_0"), hc = a._emscripten_bind_Box_length_1 = w("emscripten_bind_Box_length_1"), ic = a._emscripten_bind_Box_width_0 = w("emscripten_bind_Box_width_0"), jc = a._emscripten_bind_Box_height_0 = w("emscripten_bind_Box_height_0"), kc = a._emscripten_bind_Box_get_min_0 = w("emscripten_bind_Box_get_min_0"), lc = a._emscripten_bind_Box_set_min_1 = w("emscripten_bind_Box_set_min_1"), mc = a._emscripten_bind_Box_get_max_0 = 
w("emscripten_bind_Box_get_max_0"), nc = a._emscripten_bind_Box_set_max_1 = w("emscripten_bind_Box_set_max_1"), oc = a._emscripten_bind_Box___destroy___0 = w("emscripten_bind_Box___destroy___0"), pc = a._emscripten_bind_PolygonInterface_clear_0 = w("emscripten_bind_PolygonInterface_clear_0"), qc = a._emscripten_bind_PolygonInterface_empty_0 = w("emscripten_bind_PolygonInterface_empty_0"), rc = a._emscripten_bind_PolygonInterface_size_0 = w("emscripten_bind_PolygonInterface_size_0"), sc = a._emscripten_bind_PolygonInterface_id_0 = 
w("emscripten_bind_PolygonInterface_id_0"), tc = a._emscripten_bind_PolygonInterface_at_1 = w("emscripten_bind_PolygonInterface_at_1"), uc = a._emscripten_bind_PolygonInterface_boundingRectPolygon_0 = w("emscripten_bind_PolygonInterface_boundingRectPolygon_0"), vc = a._emscripten_bind_PolygonInterface_offsetBoundingBox_1 = w("emscripten_bind_PolygonInterface_offsetBoundingBox_1"), wc = a._emscripten_bind_PolygonInterface_offsetPolygon_1 = w("emscripten_bind_PolygonInterface_offsetPolygon_1"), xc = 
a._emscripten_bind_PolygonInterface___destroy___0 = w("emscripten_bind_PolygonInterface___destroy___0"), yc = a._emscripten_bind_Polygon_Polygon_0 = w("emscripten_bind_Polygon_Polygon_0"), zc = a._emscripten_bind_Polygon_Polygon_1 = w("emscripten_bind_Polygon_Polygon_1"), Ac = a._emscripten_bind_Polygon_setPoint_2 = w("emscripten_bind_Polygon_setPoint_2"), Bc = a._emscripten_bind_Polygon_size_0 = w("emscripten_bind_Polygon_size_0"), Cc = a._emscripten_bind_Polygon_get_ps_1 = w("emscripten_bind_Polygon_get_ps_1"), 
Dc = a._emscripten_bind_Polygon_set_ps_2 = w("emscripten_bind_Polygon_set_ps_2"), Ec = a._emscripten_bind_Polygon___destroy___0 = w("emscripten_bind_Polygon___destroy___0"), Fc = a._emscripten_bind_Point_Point_0 = w("emscripten_bind_Point_Point_0"), Gc = a._emscripten_bind_Point_Point_2 = w("emscripten_bind_Point_Point_2"), Hc = a._emscripten_bind_Point_equal_1 = w("emscripten_bind_Point_equal_1"), Ic = a._emscripten_bind_Point_get_x_0 = w("emscripten_bind_Point_get_x_0"), Jc = a._emscripten_bind_Point_set_x_1 = 
w("emscripten_bind_Point_set_x_1"), Kc = a._emscripten_bind_Point_get_y_0 = w("emscripten_bind_Point_get_y_0"), Lc = a._emscripten_bind_Point_set_y_1 = w("emscripten_bind_Point_set_y_1"), Mc = a._emscripten_bind_Point_get_id_0 = w("emscripten_bind_Point_get_id_0"), Nc = a._emscripten_bind_Point_set_id_1 = w("emscripten_bind_Point_set_id_1"), Oc = a._emscripten_bind_Point_get_vn_0 = w("emscripten_bind_Point_get_vn_0"), Pc = a._emscripten_bind_Point_set_vn_1 = w("emscripten_bind_Point_set_vn_1"), Qc = 
a._emscripten_bind_Point___destroy___0 = w("emscripten_bind_Point___destroy___0"), Rc = a._emscripten_bind_Rectangle_Rectangle_3 = w("emscripten_bind_Rectangle_Rectangle_3"), Sc = a._emscripten_bind_Rectangle___destroy___0 = w("emscripten_bind_Rectangle___destroy___0"), Tc = a._emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0 = w("emscripten_bind_HyperedgeTreeNode_HyperedgeTreeNode_0"), Uc = a._emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2 = w("emscripten_bind_HyperedgeTreeNode_writeEdgesToConns_2"), 
Vc = a._emscripten_bind_HyperedgeTreeNode___destroy___0 = w("emscripten_bind_HyperedgeTreeNode___destroy___0"), Wc = a._emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3 = w("emscripten_bind_HyperedgeTreeEdge_HyperedgeTreeEdge_3"), Xc = a._emscripten_bind_HyperedgeTreeEdge___destroy___0 = w("emscripten_bind_HyperedgeTreeEdge___destroy___0"), Yc = a._emscripten_bind_AStarPath_AStarPath_0 = w("emscripten_bind_AStarPath_AStarPath_0"), Zc = a._emscripten_bind_AStarPath_search_4 = w("emscripten_bind_AStarPath_search_4"), 
$c = a._emscripten_bind_AStarPath___destroy___0 = w("emscripten_bind_AStarPath___destroy___0"), ad = a._emscripten_bind_ConnEnd_ConnEnd_1 = w("emscripten_bind_ConnEnd_ConnEnd_1"), bd = a._emscripten_bind_ConnEnd_ConnEnd_2 = w("emscripten_bind_ConnEnd_ConnEnd_2"), cd = a._emscripten_bind_ConnEnd___destroy___0 = w("emscripten_bind_ConnEnd___destroy___0"), dd = a._emscripten_bind_ActionInfo_ActionInfo_2 = w("emscripten_bind_ActionInfo_ActionInfo_2"), ed = a._emscripten_bind_ActionInfo_ActionInfo_3 = 
w("emscripten_bind_ActionInfo_ActionInfo_3"), fd = a._emscripten_bind_ActionInfo_ActionInfo_4 = w("emscripten_bind_ActionInfo_ActionInfo_4"), gd = a._emscripten_bind_ActionInfo_obstacle_0 = w("emscripten_bind_ActionInfo_obstacle_0"), hd = a._emscripten_bind_ActionInfo_shape_0 = w("emscripten_bind_ActionInfo_shape_0"), jd = a._emscripten_bind_ActionInfo_conn_0 = w("emscripten_bind_ActionInfo_conn_0"), kd = a._emscripten_bind_ActionInfo_junction_0 = w("emscripten_bind_ActionInfo_junction_0"), ld = 
a._emscripten_bind_ActionInfo_addConnEndUpdate_3 = w("emscripten_bind_ActionInfo_addConnEndUpdate_3"), md = a._emscripten_bind_ActionInfo_get_type_0 = w("emscripten_bind_ActionInfo_get_type_0"), nd = a._emscripten_bind_ActionInfo_set_type_1 = w("emscripten_bind_ActionInfo_set_type_1"), od = a._emscripten_bind_ActionInfo_get_objPtr_0 = w("emscripten_bind_ActionInfo_get_objPtr_0"), pd = a._emscripten_bind_ActionInfo_set_objPtr_1 = w("emscripten_bind_ActionInfo_set_objPtr_1"), qd = a._emscripten_bind_ActionInfo_get_newPoly_0 = 
w("emscripten_bind_ActionInfo_get_newPoly_0"), rd = a._emscripten_bind_ActionInfo_set_newPoly_1 = w("emscripten_bind_ActionInfo_set_newPoly_1"), sd = a._emscripten_bind_ActionInfo_get_newPosition_0 = w("emscripten_bind_ActionInfo_get_newPosition_0"), td = a._emscripten_bind_ActionInfo_set_newPosition_1 = w("emscripten_bind_ActionInfo_set_newPosition_1"), ud = a._emscripten_bind_ActionInfo_get_firstMove_0 = w("emscripten_bind_ActionInfo_get_firstMove_0"), vd = a._emscripten_bind_ActionInfo_set_firstMove_1 = 
w("emscripten_bind_ActionInfo_set_firstMove_1"), wd = a._emscripten_bind_ActionInfo___destroy___0 = w("emscripten_bind_ActionInfo___destroy___0"), xd = a._emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2 = w("emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_2"), yd = a._emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3 = w("emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_3"), zd = a._emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6 = w("emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_6"), 
Ad = a._emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7 = w("emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_7"), Bd = a._emscripten_bind_ShapeConnectionPin_setConnectionCost_1 = w("emscripten_bind_ShapeConnectionPin_setConnectionCost_1"), Cd = a._emscripten_bind_ShapeConnectionPin_position_0 = w("emscripten_bind_ShapeConnectionPin_position_0"), Dd = a._emscripten_bind_ShapeConnectionPin_position_1 = w("emscripten_bind_ShapeConnectionPin_position_1"), Ed = a._emscripten_bind_ShapeConnectionPin_directions_0 = 
w("emscripten_bind_ShapeConnectionPin_directions_0"), Fd = a._emscripten_bind_ShapeConnectionPin_setExclusive_1 = w("emscripten_bind_ShapeConnectionPin_setExclusive_1"), Gd = a._emscripten_bind_ShapeConnectionPin_isExclusive_0 = w("emscripten_bind_ShapeConnectionPin_isExclusive_0"), Hd = a._emscripten_bind_ShapeConnectionPin___destroy___0 = w("emscripten_bind_ShapeConnectionPin___destroy___0"), Id = a._emscripten_bind_Obstacle_id_0 = w("emscripten_bind_Obstacle_id_0"), Jd = a._emscripten_bind_Obstacle_polygon_0 = 
w("emscripten_bind_Obstacle_polygon_0"), Kd = a._emscripten_bind_Obstacle_router_0 = w("emscripten_bind_Obstacle_router_0"), Ld = a._emscripten_bind_Obstacle_position_0 = w("emscripten_bind_Obstacle_position_0"), Md = a._emscripten_bind_Obstacle___destroy___0 = w("emscripten_bind_Obstacle___destroy___0"), Nd = a._emscripten_bind_JunctionRef_JunctionRef_2 = w("emscripten_bind_JunctionRef_JunctionRef_2"), Od = a._emscripten_bind_JunctionRef_JunctionRef_3 = w("emscripten_bind_JunctionRef_JunctionRef_3"), 
Pd = a._emscripten_bind_JunctionRef_position_0 = w("emscripten_bind_JunctionRef_position_0"), Qd = a._emscripten_bind_JunctionRef___destroy___0 = w("emscripten_bind_JunctionRef___destroy___0"), Rd = a._emscripten_bind_ShapeRef_ShapeRef_2 = w("emscripten_bind_ShapeRef_ShapeRef_2"), Sd = a._emscripten_bind_ShapeRef_ShapeRef_3 = w("emscripten_bind_ShapeRef_ShapeRef_3"), Td = a._emscripten_bind_ShapeRef_polygon_0 = w("emscripten_bind_ShapeRef_polygon_0"), Ud = a._emscripten_bind_ShapeRef_position_0 = 
w("emscripten_bind_ShapeRef_position_0"), Vd = a._emscripten_bind_ShapeRef___destroy___0 = w("emscripten_bind_ShapeRef___destroy___0"), Wd = a._emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0 = w("emscripten_bind_HyperedgeNewAndDeletedObjectLists___destroy___0"), Xd = a._emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0 = w("emscripten_bind_HyperedgeRerouter_HyperedgeRerouter_0"), Yd = a._emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1 = w("emscripten_bind_HyperedgeRerouter_registerHyperedgeForRerouting_1"), 
Zd = a._emscripten_bind_HyperedgeRerouter___destroy___0 = w("emscripten_bind_HyperedgeRerouter___destroy___0"), $d = a._emscripten_bind_VertInf___destroy___0 = w("emscripten_bind_VertInf___destroy___0"), ae = a._emscripten_bind_VertID_VertID_0 = w("emscripten_bind_VertID_VertID_0"), be = a._emscripten_bind_VertID_VertID_2 = w("emscripten_bind_VertID_VertID_2"), ce = a._emscripten_bind_VertID_VertID_3 = w("emscripten_bind_VertID_VertID_3"), de = a._emscripten_bind_VertID_get_objID_0 = w("emscripten_bind_VertID_get_objID_0"), 
ee = a._emscripten_bind_VertID_set_objID_1 = w("emscripten_bind_VertID_set_objID_1"), fe = a._emscripten_bind_VertID_get_vn_0 = w("emscripten_bind_VertID_get_vn_0"), ge = a._emscripten_bind_VertID_set_vn_1 = w("emscripten_bind_VertID_set_vn_1"), he = a._emscripten_bind_VertID_get_props_0 = w("emscripten_bind_VertID_get_props_0"), ie = a._emscripten_bind_VertID_set_props_1 = w("emscripten_bind_VertID_set_props_1"), je = a._emscripten_bind_VertID_get_src_0 = w("emscripten_bind_VertID_get_src_0"), ke = 
a._emscripten_bind_VertID_get_tar_0 = w("emscripten_bind_VertID_get_tar_0"), le = a._emscripten_bind_VertID_get_PROP_ConnPoint_0 = w("emscripten_bind_VertID_get_PROP_ConnPoint_0"), me = a._emscripten_bind_VertID_get_PROP_OrthShapeEdge_0 = w("emscripten_bind_VertID_get_PROP_OrthShapeEdge_0"), ne = a._emscripten_bind_VertID_get_PROP_ConnectionPin_0 = w("emscripten_bind_VertID_get_PROP_ConnectionPin_0"), oe = a._emscripten_bind_VertID_get_PROP_ConnCheckpoint_0 = w("emscripten_bind_VertID_get_PROP_ConnCheckpoint_0"), 
pe = a._emscripten_bind_VertID_get_PROP_DummyPinHelper_0 = w("emscripten_bind_VertID_get_PROP_DummyPinHelper_0"), qe = a._emscripten_bind_VertID___destroy___0 = w("emscripten_bind_VertID___destroy___0"), re = a._emscripten_bind_MinimumTerminalSpanningTree___destroy___0 = w("emscripten_bind_MinimumTerminalSpanningTree___destroy___0"), se = a._emscripten_bind_Checkpoint_Checkpoint_1 = w("emscripten_bind_Checkpoint_Checkpoint_1"), te = a._emscripten_bind_Checkpoint___destroy___0 = w("emscripten_bind_Checkpoint___destroy___0"), 
ue = a._emscripten_bind_ConnRef_ConnRef_3 = w("emscripten_bind_ConnRef_ConnRef_3"), ve = a._emscripten_bind_ConnRef_ConnRef_4 = w("emscripten_bind_ConnRef_ConnRef_4"), we = a._emscripten_bind_ConnRef_id_0 = w("emscripten_bind_ConnRef_id_0"), xe = a._emscripten_bind_ConnRef_setCallback_2 = w("emscripten_bind_ConnRef_setCallback_2"), ye = a._emscripten_bind_ConnRef_setSourceEndpoint_1 = w("emscripten_bind_ConnRef_setSourceEndpoint_1"), ze = a._emscripten_bind_ConnRef_setDestEndpoint_1 = w("emscripten_bind_ConnRef_setDestEndpoint_1"), 
Ae = a._emscripten_bind_ConnRef_routingType_0 = w("emscripten_bind_ConnRef_routingType_0"), Be = a._emscripten_bind_ConnRef_setRoutingType_1 = w("emscripten_bind_ConnRef_setRoutingType_1"), Ce = a._emscripten_bind_ConnRef_displayRoute_0 = w("emscripten_bind_ConnRef_displayRoute_0"), De = a._emscripten_bind_ConnRef_setHateCrossings_1 = w("emscripten_bind_ConnRef_setHateCrossings_1"), Ee = a._emscripten_bind_ConnRef_doesHateCrossings_0 = w("emscripten_bind_ConnRef_doesHateCrossings_0"), Fe = a._emscripten_bind_ConnRef___destroy___0 = 
w("emscripten_bind_ConnRef___destroy___0"), Ge = a._emscripten_bind_EdgeInf_EdgeInf_2 = w("emscripten_bind_EdgeInf_EdgeInf_2"), He = a._emscripten_bind_EdgeInf_EdgeInf_3 = w("emscripten_bind_EdgeInf_EdgeInf_3"), Ie = a._emscripten_bind_EdgeInf___destroy___0 = w("emscripten_bind_EdgeInf___destroy___0"), Je = a._emscripten_bind_LineRep_get_begin_0 = w("emscripten_bind_LineRep_get_begin_0"), Ke = a._emscripten_bind_LineRep_set_begin_1 = w("emscripten_bind_LineRep_set_begin_1"), Le = a._emscripten_bind_LineRep_get_end_0 = 
w("emscripten_bind_LineRep_get_end_0"), Me = a._emscripten_bind_LineRep_set_end_1 = w("emscripten_bind_LineRep_set_end_1"), Ne = a._emscripten_bind_LineRep___destroy___0 = w("emscripten_bind_LineRep___destroy___0"), Oe = a._emscripten_bind_Router_Router_1 = w("emscripten_bind_Router_Router_1"), Pe = a._emscripten_bind_Router_processTransaction_0 = w("emscripten_bind_Router_processTransaction_0"), Qe = a._emscripten_bind_Router_printInfo_0 = w("emscripten_bind_Router_printInfo_0"), Re = a._emscripten_bind_Router_deleteConnector_1 = 
w("emscripten_bind_Router_deleteConnector_1"), Se = a._emscripten_bind_Router_moveShape_3 = w("emscripten_bind_Router_moveShape_3"), Te = a._emscripten_bind_Router_setRoutingParameter_2 = w("emscripten_bind_Router_setRoutingParameter_2"), Ue = a._emscripten_bind_Router_setRoutingOption_2 = w("emscripten_bind_Router_setRoutingOption_2"), Ve = a._emscripten_bind_Router___destroy___0 = w("emscripten_bind_Router___destroy___0"), We = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirNone = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirNone"), 
Xe = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirUp = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirUp"), Ye = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirDown = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirDown"), Ze = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirLeft"), $e = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirRight = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirRight"), af = a._emscripten_enum_Avoid_ConnDirFlag_ConnDirAll = w("emscripten_enum_Avoid_ConnDirFlag_ConnDirAll"), 
bf = a._emscripten_enum_Avoid_ConnEndType_ConnEndPoint = w("emscripten_enum_Avoid_ConnEndType_ConnEndPoint"), cf = a._emscripten_enum_Avoid_ConnEndType_ConnEndShapePin = w("emscripten_enum_Avoid_ConnEndType_ConnEndShapePin"), df = a._emscripten_enum_Avoid_ConnEndType_ConnEndJunction = w("emscripten_enum_Avoid_ConnEndType_ConnEndJunction"), ef = a._emscripten_enum_Avoid_ConnEndType_ConnEndEmpty = w("emscripten_enum_Avoid_ConnEndType_ConnEndEmpty"), ff = a._emscripten_enum_Avoid_ActionType_ShapeMove = 
w("emscripten_enum_Avoid_ActionType_ShapeMove"), gf = a._emscripten_enum_Avoid_ActionType_ShapeAdd = w("emscripten_enum_Avoid_ActionType_ShapeAdd"), hf = a._emscripten_enum_Avoid_ActionType_ShapeRemove = w("emscripten_enum_Avoid_ActionType_ShapeRemove"), jf = a._emscripten_enum_Avoid_ActionType_JunctionMove = w("emscripten_enum_Avoid_ActionType_JunctionMove"), kf = a._emscripten_enum_Avoid_ActionType_JunctionAdd = w("emscripten_enum_Avoid_ActionType_JunctionAdd"), lf = a._emscripten_enum_Avoid_ActionType_JunctionRemove = 
w("emscripten_enum_Avoid_ActionType_JunctionRemove"), mf = a._emscripten_enum_Avoid_ActionType_ConnChange = w("emscripten_enum_Avoid_ActionType_ConnChange"), nf = a._emscripten_enum_Avoid_ActionType_ConnectionPinChange = w("emscripten_enum_Avoid_ActionType_ConnectionPinChange"), of = a._emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90 = w("emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW90"), pf = a._emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180 = 
w("emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW180"), qf = a._emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270 = w("emscripten_enum_Avoid_ShapeTransformationType_TransformationType_CW270"), rf = a._emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX = w("emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipX"), sf = a._emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY = w("emscripten_enum_Avoid_ShapeTransformationType_TransformationType_FlipY"), 
tf = a._emscripten_enum_Avoid_ConnType_ConnType_None = w("emscripten_enum_Avoid_ConnType_ConnType_None"), uf = a._emscripten_enum_Avoid_ConnType_ConnType_PolyLine = w("emscripten_enum_Avoid_ConnType_ConnType_PolyLine"), vf = a._emscripten_enum_Avoid_ConnType_ConnType_Orthogonal = w("emscripten_enum_Avoid_ConnType_ConnType_Orthogonal"), wf = a._emscripten_enum_Avoid_RouterFlag_PolyLineRouting = w("emscripten_enum_Avoid_RouterFlag_PolyLineRouting"), xf = a._emscripten_enum_Avoid_RouterFlag_OrthogonalRouting = 
w("emscripten_enum_Avoid_RouterFlag_OrthogonalRouting"), yf = a._emscripten_enum_Avoid_RoutingParameter_segmentPenalty = w("emscripten_enum_Avoid_RoutingParameter_segmentPenalty"), zf = a._emscripten_enum_Avoid_RoutingParameter_anglePenalty = w("emscripten_enum_Avoid_RoutingParameter_anglePenalty"), Af = a._emscripten_enum_Avoid_RoutingParameter_crossingPenalty = w("emscripten_enum_Avoid_RoutingParameter_crossingPenalty"), Bf = a._emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty = w("emscripten_enum_Avoid_RoutingParameter_clusterCrossingPenalty"), 
Cf = a._emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty = w("emscripten_enum_Avoid_RoutingParameter_fixedSharedPathPenalty"), Df = a._emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty = w("emscripten_enum_Avoid_RoutingParameter_portDirectionPenalty"), Ef = a._emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance = w("emscripten_enum_Avoid_RoutingParameter_shapeBufferDistance"), Ff = a._emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance = w("emscripten_enum_Avoid_RoutingParameter_idealNudgingDistance"), 
Gf = a._emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty = w("emscripten_enum_Avoid_RoutingParameter_reverseDirectionPenalty"), Hf = a._emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes = w("emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalSegmentsConnectedToShapes"), If = a._emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions = w("emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingJunctions"), Jf = a._emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds = 
w("emscripten_enum_Avoid_RoutingOption_penaliseOrthogonalSharedPathsAtConnEnds"), Kf = a._emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments = w("emscripten_enum_Avoid_RoutingOption_nudgeOrthogonalTouchingColinearSegments"), Lf = a._emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep = w("emscripten_enum_Avoid_RoutingOption_performUnifyingNudgingPreprocessingStep"), Mf = a._emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions = 
w("emscripten_enum_Avoid_RoutingOption_improveHyperedgeRoutesMovingAddingAndDeletingJunctions"), Nf = a._emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint = w("emscripten_enum_Avoid_RoutingOption_nudgeSharedPathsWithCommonEndPoint");
a.___errno_location = w("__errno_location");
a.___stdio_exit = w("__stdio_exit");
var y = a._setThrew = w("setThrew"), Of = a._emscripten_stack_init = function() {
  return (Of = a._emscripten_stack_init = a.asm.emscripten_stack_init).apply(null, arguments);
};
a._emscripten_stack_get_free = function() {
  return (a._emscripten_stack_get_free = a.asm.emscripten_stack_get_free).apply(null, arguments);
};
a._emscripten_stack_get_base = function() {
  return (a._emscripten_stack_get_base = a.asm.emscripten_stack_get_base).apply(null, arguments);
};
var Ea = a._emscripten_stack_get_end = function() {
  return (Ea = a._emscripten_stack_get_end = a.asm.emscripten_stack_get_end).apply(null, arguments);
}, z = a.stackSave = w("stackSave"), A = a.stackRestore = w("stackRestore");
a.stackAlloc = w("stackAlloc");
var qb = a.___cxa_can_catch = w("__cxa_can_catch"), bb = a.___cxa_is_pointer_type = w("__cxa_is_pointer_type"), Pf = a.dynCall_iiij = w("dynCall_iiij");
a.dynCall_jiji = w("dynCall_jiji");
a.dynCall_viijii = w("dynCall_viijii");
a.dynCall_iiiiij = w("dynCall_iiiiij");
a.dynCall_iiiiijj = w("dynCall_iiiiijj");
a.dynCall_iiiiiijj = w("dynCall_iiiiiijj");
function xb(b, c) {
  var e = z();
  try {
    return x(b)(c);
  } catch (h) {
    A(e);
    if (h !== h + 0) {
      throw h;
    }
    y(1, 0);
  }
}
function Ub(b, c, e, h) {
  var k = z();
  try {
    x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function Cb(b, c, e, h) {
  var k = z();
  try {
    return x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function Ib(b, c, e, h, k, l) {
  var n = z();
  try {
    return x(b)(c, e, h, k, l);
  } catch (t) {
    A(n);
    if (t !== t + 0) {
      throw t;
    }
    y(1, 0);
  }
}
function zb(b, c, e) {
  var h = z();
  try {
    return x(b)(c, e);
  } catch (k) {
    A(h);
    if (k !== k + 0) {
      throw k;
    }
    y(1, 0);
  }
}
function Ob(b) {
  var c = z();
  try {
    x(b)();
  } catch (e) {
    A(c);
    if (e !== e + 0) {
      throw e;
    }
    y(1, 0);
  }
}
function Xb(b, c, e, h, k, l) {
  var n = z();
  try {
    x(b)(c, e, h, k, l);
  } catch (t) {
    A(n);
    if (t !== t + 0) {
      throw t;
    }
    y(1, 0);
  }
}
function Sb(b, c, e) {
  var h = z();
  try {
    x(b)(c, e);
  } catch (k) {
    A(h);
    if (k !== k + 0) {
      throw k;
    }
    y(1, 0);
  }
}
function Db(b, c, e, h, k) {
  var l = z();
  try {
    return x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function Pb(b, c) {
  var e = z();
  try {
    x(b)(c);
  } catch (h) {
    A(e);
    if (h !== h + 0) {
      throw h;
    }
    y(1, 0);
  }
}
function Gb(b, c, e, h, k) {
  var l = z();
  try {
    return x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function Wb(b, c, e, h, k) {
  var l = z();
  try {
    x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function vb(b, c, e, h, k) {
  var l = z();
  try {
    return x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function tb(b, c, e) {
  var h = z();
  try {
    return x(b)(c, e);
  } catch (k) {
    A(h);
    if (k !== k + 0) {
      throw k;
    }
    y(1, 0);
  }
}
function sb(b, c, e, h, k, l) {
  var n = z();
  try {
    return x(b)(c, e, h, k, l);
  } catch (t) {
    A(n);
    if (t !== t + 0) {
      throw t;
    }
    y(1, 0);
  }
}
function ub(b, c, e, h) {
  var k = z();
  try {
    return x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function Jb(b, c, e, h, k, l, n) {
  var t = z();
  try {
    return x(b)(c, e, h, k, l, n);
  } catch (F) {
    A(t);
    if (F !== F + 0) {
      throw F;
    }
    y(1, 0);
  }
}
function Ab(b, c, e, h) {
  var k = z();
  try {
    return x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function Rb(b, c, e, h) {
  var k = z();
  try {
    x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function Bb(b, c, e, h, k) {
  var l = z();
  try {
    return x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function Eb(b, c, e, h, k, l, n, t) {
  var F = z();
  try {
    return x(b)(c, e, h, k, l, n, t);
  } catch (B) {
    A(F);
    if (B !== B + 0) {
      throw B;
    }
    y(1, 0);
  }
}
function Fb(b, c, e, h, k, l, n, t, F) {
  var B = z();
  try {
    return x(b)(c, e, h, k, l, n, t, F);
  } catch (G) {
    A(B);
    if (G !== G + 0) {
      throw G;
    }
    y(1, 0);
  }
}
function Qb(b, c, e) {
  var h = z();
  try {
    x(b)(c, e);
  } catch (k) {
    A(h);
    if (k !== k + 0) {
      throw k;
    }
    y(1, 0);
  }
}
function Tb(b, c, e, h) {
  var k = z();
  try {
    x(b)(c, e, h);
  } catch (l) {
    A(k);
    if (l !== l + 0) {
      throw l;
    }
    y(1, 0);
  }
}
function yb(b, c, e) {
  var h = z();
  try {
    return x(b)(c, e);
  } catch (k) {
    A(h);
    if (k !== k + 0) {
      throw k;
    }
    y(1, 0);
  }
}
function Lb(b, c, e, h, k, l, n, t, F, B) {
  var G = z();
  try {
    return x(b)(c, e, h, k, l, n, t, F, B);
  } catch (N) {
    A(G);
    if (N !== N + 0) {
      throw N;
    }
    y(1, 0);
  }
}
function Vb(b, c, e, h, k) {
  var l = z();
  try {
    x(b)(c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
function rb(b, c) {
  var e = z();
  try {
    return x(b)(c);
  } catch (h) {
    A(e);
    if (h !== h + 0) {
      throw h;
    }
    y(1, 0);
  }
}
function Hb(b, c, e, h, k, l) {
  var n = z();
  try {
    return x(b)(c, e, h, k, l);
  } catch (t) {
    A(n);
    if (t !== t + 0) {
      throw t;
    }
    y(1, 0);
  }
}
function Kb(b, c, e, h, k, l, n, t) {
  var F = z();
  try {
    return x(b)(c, e, h, k, l, n, t);
  } catch (B) {
    A(F);
    if (B !== B + 0) {
      throw B;
    }
    y(1, 0);
  }
}
function Yb(b, c, e, h, k, l, n, t) {
  var F = z();
  try {
    x(b)(c, e, h, k, l, n, t);
  } catch (B) {
    A(F);
    if (B !== B + 0) {
      throw B;
    }
    y(1, 0);
  }
}
function Mb(b, c, e, h, k, l, n, t, F, B, G, N) {
  var Z = z();
  try {
    return x(b)(c, e, h, k, l, n, t, F, B, G, N);
  } catch (m) {
    A(Z);
    if (m !== m + 0) {
      throw m;
    }
    y(1, 0);
  }
}
function Zb(b, c, e, h, k, l, n, t, F, B, G) {
  var N = z();
  try {
    x(b)(c, e, h, k, l, n, t, F, B, G);
  } catch (Z) {
    A(N);
    if (Z !== Z + 0) {
      throw Z;
    }
    y(1, 0);
  }
}
function $b(b, c, e, h, k, l, n, t, F, B, G, N, Z, m, D, I) {
  var ea = z();
  try {
    x(b)(c, e, h, k, l, n, t, F, B, G, N, Z, m, D, I);
  } catch (va) {
    A(ea);
    if (va !== va + 0) {
      throw va;
    }
    y(1, 0);
  }
}
function wb(b) {
  var c = z();
  try {
    return x(b)();
  } catch (e) {
    A(c);
    if (e !== e + 0) {
      throw e;
    }
    y(1, 0);
  }
}
function Nb(b, c, e, h, k) {
  var l = z();
  try {
    return Pf(b, c, e, h, k);
  } catch (n) {
    A(l);
    if (n !== n + 0) {
      throw n;
    }
    y(1, 0);
  }
}
q("intArrayFromString", !1);
q("intArrayToString", !1);
q("ccall", !1);
q("cwrap", !1);
q("setValue", !1);
q("getValue", !1);
q("allocate", !1);
q("UTF8ArrayToString", !1);
q("UTF8ToString", !1);
q("stringToUTF8Array", !1);
q("stringToUTF8", !1);
q("lengthBytesUTF8", !1);
q("stackTrace", !1);
q("addOnPreRun", !1);
q("addOnInit", !1);
q("addOnPreMain", !1);
q("addOnExit", !1);
q("addOnPostRun", !1);
q("writeStringToMemory", !1);
q("writeArrayToMemory", !1);
q("writeAsciiToMemory", !1);
q("addRunDependency", !0);
q("removeRunDependency", !0);
q("FS_createFolder", !1);
q("FS_createPath", !0);
q("FS_createDataFile", !0);
q("FS_createPreloadedFile", !0);
q("FS_createLazyFile", !0);
q("FS_createLink", !1);
q("FS_createDevice", !0);
q("FS_unlink", !0);
q("getLEB", !1);
q("getFunctionTables", !1);
q("alignFunctionTables", !1);
q("registerFunctions", !1);
q("addFunction", !1);
q("removeFunction", !1);
q("getFuncWrapper", !1);
q("prettyPrint", !1);
q("dynCall", !1);
q("getCompilerSetting", !1);
q("print", !1);
q("printErr", !1);
q("getTempRet0", !1);
q("setTempRet0", !1);
q("callMain", !1);
q("abort", !1);
q("keepRuntimeAlive", !1);
q("zeroMemory", !1);
q("stringToNewUTF8", !1);
q("emscripten_realloc_buffer", !1);
q("ENV", !1);
q("ERRNO_CODES", !1);
q("ERRNO_MESSAGES", !1);
q("setErrNo", !1);
q("inetPton4", !1);
q("inetNtop4", !1);
q("inetPton6", !1);
q("inetNtop6", !1);
q("readSockaddr", !1);
q("writeSockaddr", !1);
q("DNS", !1);
q("getHostByName", !1);
q("Protocols", !1);
q("Sockets", !1);
q("getRandomDevice", !1);
q("traverseStack", !1);
q("UNWIND_CACHE", !1);
q("convertPCtoSourceLocation", !1);
q("readAsmConstArgsArray", !1);
q("readAsmConstArgs", !1);
q("mainThreadEM_ASM", !1);
q("jstoi_q", !1);
q("jstoi_s", !1);
q("getExecutableName", !1);
q("listenOnce", !1);
q("autoResumeAudioContext", !1);
q("dynCallLegacy", !1);
q("getDynCaller", !1);
q("dynCall", !1);
q("handleException", !1);
q("runtimeKeepalivePush", !1);
q("runtimeKeepalivePop", !1);
q("callUserCallback", !1);
q("maybeExit", !1);
q("safeSetTimeout", !1);
q("asmjsMangle", !1);
q("asyncLoad", !1);
q("alignMemory", !1);
q("mmapAlloc", !1);
q("reallyNegative", !1);
q("unSign", !1);
q("reSign", !1);
q("formatString", !1);
q("PATH", !1);
q("PATH_FS", !1);
q("SYSCALLS", !1);
q("getSocketFromFD", !1);
q("getSocketAddress", !1);
q("JSEvents", !1);
q("registerKeyEventCallback", !1);
q("specialHTMLTargets", !1);
q("maybeCStringToJsString", !1);
q("findEventTarget", !1);
q("findCanvasEventTarget", !1);
q("getBoundingClientRect", !1);
q("fillMouseEventData", !1);
q("registerMouseEventCallback", !1);
q("registerWheelEventCallback", !1);
q("registerUiEventCallback", !1);
q("registerFocusEventCallback", !1);
q("fillDeviceOrientationEventData", !1);
q("registerDeviceOrientationEventCallback", !1);
q("fillDeviceMotionEventData", !1);
q("registerDeviceMotionEventCallback", !1);
q("screenOrientation", !1);
q("fillOrientationChangeEventData", !1);
q("registerOrientationChangeEventCallback", !1);
q("fillFullscreenChangeEventData", !1);
q("registerFullscreenChangeEventCallback", !1);
q("registerRestoreOldStyle", !1);
q("hideEverythingExceptGivenElement", !1);
q("restoreHiddenElements", !1);
q("setLetterbox", !1);
q("currentFullscreenStrategy", !1);
q("restoreOldWindowedStyle", !1);
q("softFullscreenResizeWebGLRenderTarget", !1);
q("doRequestFullscreen", !1);
q("fillPointerlockChangeEventData", !1);
q("registerPointerlockChangeEventCallback", !1);
q("registerPointerlockErrorEventCallback", !1);
q("requestPointerLock", !1);
q("fillVisibilityChangeEventData", !1);
q("registerVisibilityChangeEventCallback", !1);
q("registerTouchEventCallback", !1);
q("fillGamepadEventData", !1);
q("registerGamepadEventCallback", !1);
q("registerBeforeUnloadEventCallback", !1);
q("fillBatteryEventData", !1);
q("battery", !1);
q("registerBatteryEventCallback", !1);
q("setCanvasElementSize", !1);
q("getCanvasElementSize", !1);
q("demangle", !1);
q("demangleAll", !1);
q("jsStackTrace", !1);
q("stackTrace", !1);
q("getEnvStrings", !1);
q("checkWasiClock", !1);
q("flush_NO_FILESYSTEM", !1);
q("writeI53ToI64", !1);
q("writeI53ToI64Clamped", !1);
q("writeI53ToI64Signaling", !1);
q("writeI53ToU64Clamped", !1);
q("writeI53ToU64Signaling", !1);
q("readI53FromI64", !1);
q("readI53FromU64", !1);
q("convertI32PairToI53", !1);
q("convertU32PairToI53", !1);
q("setImmediateWrapped", !1);
q("clearImmediateWrapped", !1);
q("polyfillSetImmediate", !1);
q("uncaughtExceptionCount", !1);
q("exceptionLast", !1);
q("exceptionCaught", !1);
q("ExceptionInfo", !1);
q("CatchInfo", !1);
q("exception_addRef", !1);
q("exception_decRef", !1);
q("formatException", !1);
q("Browser", !1);
q("funcWrappers", !1);
q("getFuncWrapper", !1);
q("setMainLoop", !1);
q("wget", !1);
q("tempFixedLengthArray", !1);
q("miniTempWebGLFloatBuffers", !1);
q("heapObjectForWebGLType", !1);
q("heapAccessShiftForWebGLHeap", !1);
q("GL", !1);
q("emscriptenWebGLGet", !1);
q("computeUnpackAlignedImageSize", !1);
q("emscriptenWebGLGetTexPixelData", !1);
q("emscriptenWebGLGetUniform", !1);
q("webglGetUniformLocation", !1);
q("webglPrepareUniformLocationsBeforeFirstUse", !1);
q("webglGetLeftBracePos", !1);
q("emscriptenWebGLGetVertexAttrib", !1);
q("writeGLArray", !1);
q("AL", !1);
q("SDL_unicode", !1);
q("SDL_ttfContext", !1);
q("SDL_audio", !1);
q("SDL", !1);
q("SDL_gfx", !1);
q("GLUT", !1);
q("EGL", !1);
q("GLFW_Window", !1);
q("GLFW", !1);
q("GLEW", !1);
q("IDBStore", !1);
q("runAndAbortIfError", !1);
q("warnOnce", !1);
q("stackSave", !1);
q("stackRestore", !1);
q("stackAlloc", !1);
q("AsciiToString", !1);
q("stringToAscii", !1);
q("UTF16ToString", !1);
q("stringToUTF16", !1);
q("lengthBytesUTF16", !1);
q("UTF32ToString", !1);
q("stringToUTF32", !1);
q("lengthBytesUTF32", !1);
q("allocateUTF8", !1);
q("allocateUTF8OnStack", !1);
a.writeStackCookie = Da;
a.checkStackCookie = Fa;
na("ALLOC_NORMAL");
na("ALLOC_STACK");
var Qf;
Pa = function Rf() {
  Qf || Sf();
  Qf || (Pa = Rf);
};
function Sf() {
  function b() {
    if (!Qf && (Qf = !0, a.calledRun = !0, !qa)) {
      Fa();
      p(!La);
      La = !0;
      Xa(Ja);
      aa(a);
      if (a.onRuntimeInitialized) {
        a.onRuntimeInitialized();
      }
      p(!a._main, 'compiled without a main, but one is present. if you added it from JS, use Module["onRuntimeInitialized"]');
      Fa();
      if (a.postRun) {
        for ("function" == typeof a.postRun && (a.postRun = [a.postRun]); a.postRun.length;) {
          var c = a.postRun.shift();
          Ka.unshift(c);
        }
      }
      Xa(Ka);
    }
  }
  if (!(0 < Na)) {
    Of();
    Da();
    if (a.preRun) {
      for ("function" == typeof a.preRun && (a.preRun = [a.preRun]); a.preRun.length;) {
        Ma();
      }
    }
    Xa(Ia);
    0 < Na || (a.setStatus ? (a.setStatus("Running..."), setTimeout(function() {
      setTimeout(function() {
        a.setStatus("");
      }, 1);
      b();
    }, 1)) : b(), Fa());
  }
}
a.run = Sf;
if (a.preInit) {
  for ("function" == typeof a.preInit && (a.preInit = [a.preInit]); 0 < a.preInit.length;) {
    a.preInit.pop()();
  }
}
Sf();
function C() {
}
C.prototype = Object.create(C.prototype);
C.prototype.constructor = C;
C.prototype.h = C;
C.l = {};
a.WrapperObject = C;
function E(b) {
  return (b || C).l;
}
a.getCache = E;
function H(b, c) {
  var e = E(c), h = e[b];
  if (h) {
    return h;
  }
  h = Object.create((c || C).prototype);
  h.g = b;
  return e[b] = h;
}
a.wrapPointer = H;
a.castObject = function(b, c) {
  return H(b.g, c);
};
a.NULL = H(0);
a.destroy = function(b) {
  if (!b.__destroy__) {
    throw "Error: Cannot destroy object. (Did you create it yourself?)";
  }
  b.__destroy__();
  delete E(b.h)[b.g];
};
a.compare = function(b, c) {
  return b.g === c.g;
};
a.getPointer = function(b) {
  return b.g;
};
a.getClass = function(b) {
  return b.h;
};
var Tf = 0, Uf = 0, Vf = [], Wf = 0;
function Xf() {
  throw "cannot construct a VoidPtr, no constructor in IDL";
}
Xf.prototype = Object.create(C.prototype);
Xf.prototype.constructor = Xf;
Xf.prototype.h = Xf;
Xf.l = {};
a.VoidPtr = Xf;
Xf.prototype.__destroy__ = function() {
  bc(this.g);
};
function J() {
  this.g = cc();
  E(J)[this.g] = this;
}
J.prototype = Object.create(C.prototype);
J.prototype.constructor = J;
J.prototype.h = J;
J.l = {};
a.HyperedgeImprover = J;
J.prototype.clear = J.prototype.clear = function() {
  dc(this.g);
};
J.prototype.setRouter = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ec(c, b);
};
J.prototype.__destroy__ = function() {
  fc(this.g);
};
function K() {
  this.g = gc();
  E(K)[this.g] = this;
}
K.prototype = Object.create(C.prototype);
K.prototype.constructor = K;
K.prototype.h = K;
K.l = {};
a.Box = K;
K.prototype.length = K.prototype.length = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return hc(c, b);
};
K.prototype.width = K.prototype.width = function() {
  return ic(this.g);
};
K.prototype.height = K.prototype.height = function() {
  return jc(this.g);
};
K.prototype.get_min = K.prototype.fa = function() {
  return H(kc(this.g), L);
};
K.prototype.set_min = K.prototype.xa = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  lc(c, b);
};
Object.defineProperty(K.prototype, "min", {get:K.prototype.fa, set:K.prototype.xa});
K.prototype.get_max = K.prototype.ea = function() {
  return H(mc(this.g), L);
};
K.prototype.set_max = K.prototype.wa = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  nc(c, b);
};
Object.defineProperty(K.prototype, "max", {get:K.prototype.ea, set:K.prototype.wa});
K.prototype.__destroy__ = function() {
  oc(this.g);
};
function M() {
  throw "cannot construct a PolygonInterface, no constructor in IDL";
}
M.prototype = Object.create(C.prototype);
M.prototype.constructor = M;
M.prototype.h = M;
M.l = {};
a.PolygonInterface = M;
M.prototype.clear = M.prototype.clear = function() {
  pc(this.g);
};
M.prototype.empty = M.prototype.empty = function() {
  return !!qc(this.g);
};
M.prototype.size = M.prototype.size = function() {
  return rc(this.g);
};
M.prototype.id = M.prototype.id = function() {
  return sc(this.g);
};
M.prototype.at = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return H(tc(c, b), L);
};
M.prototype.boundingRectPolygon = function() {
  return H(uc(this.g), O);
};
M.prototype.offsetBoundingBox = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return H(vc(c, b), K);
};
M.prototype.offsetPolygon = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return H(wc(c, b), O);
};
M.prototype.__destroy__ = function() {
  xc(this.g);
};
function O(b) {
  b && "object" === typeof b && (b = b.g);
  this.g = void 0 === b ? yc() : zc(b);
  E(O)[this.g] = this;
}
O.prototype = Object.create(C.prototype);
O.prototype.constructor = O;
O.prototype.h = O;
O.l = {};
a.Polygon = O;
O.prototype.setPoint = function(b, c) {
  var e = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  Ac(e, b, c);
};
O.prototype.size = O.prototype.size = function() {
  return Bc(this.g);
};
O.prototype.get_ps = O.prototype.la = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return H(Cc(c, b), L);
};
O.prototype.set_ps = O.prototype.Da = function(b, c) {
  var e = this.g;
  if (Wf) {
    for (var h = 0; h < Vf.length; h++) {
      a._free(Vf[h]);
    }
    Vf.length = 0;
    a._free(Tf);
    Tf = 0;
    Uf += Wf;
    Wf = 0;
  }
  Tf || (Uf += 128, Tf = a._malloc(Uf), p(Tf));
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  Dc(e, b, c);
};
Object.defineProperty(O.prototype, "ps", {get:O.prototype.la, set:O.prototype.Da});
O.prototype.__destroy__ = function() {
  Ec(this.g);
};
function L(b, c) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  this.g = void 0 === b ? Fc() : void 0 === c ? _emscripten_bind_Point_Point_1(b) : Gc(b, c);
  E(L)[this.g] = this;
}
L.prototype = Object.create(C.prototype);
L.prototype.constructor = L;
L.prototype.h = L;
L.l = {};
a.Point = L;
L.prototype.equal = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return !!Hc(c, b);
};
L.prototype.get_x = L.prototype.oa = function() {
  return Ic(this.g);
};
L.prototype.set_x = L.prototype.Ea = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Jc(c, b);
};
Object.defineProperty(L.prototype, "x", {get:L.prototype.oa, set:L.prototype.Ea});
L.prototype.get_y = L.prototype.pa = function() {
  return Kc(this.g);
};
L.prototype.set_y = L.prototype.Fa = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Lc(c, b);
};
Object.defineProperty(L.prototype, "y", {get:L.prototype.pa, set:L.prototype.Fa});
L.prototype.get_id = L.prototype.da = function() {
  return Mc(this.g);
};
L.prototype.set_id = L.prototype.va = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Nc(c, b);
};
Object.defineProperty(L.prototype, "id", {get:L.prototype.da, set:L.prototype.va});
L.prototype.get_vn = L.prototype.J = function() {
  return Oc(this.g);
};
L.prototype.set_vn = L.prototype.N = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Pc(c, b);
};
Object.defineProperty(L.prototype, "vn", {get:L.prototype.J, set:L.prototype.N});
L.prototype.__destroy__ = function() {
  Qc(this.g);
};
function Yf(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = Rc(b, c, e);
  E(Yf)[this.g] = this;
}
Yf.prototype = Object.create(C.prototype);
Yf.prototype.constructor = Yf;
Yf.prototype.h = Yf;
Yf.l = {};
a.Rectangle = Yf;
Yf.prototype.__destroy__ = function() {
  Sc(this.g);
};
function Zf() {
  this.g = Tc();
  E(Zf)[this.g] = this;
}
Zf.prototype = Object.create(C.prototype);
Zf.prototype.constructor = Zf;
Zf.prototype.h = Zf;
Zf.l = {};
a.HyperedgeTreeNode = Zf;
Zf.prototype.writeEdgesToConns = function(b, c) {
  var e = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  Uc(e, b, c);
};
Zf.prototype.__destroy__ = function() {
  Vc(this.g);
};
function $f(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = Wc(b, c, e);
  E($f)[this.g] = this;
}
$f.prototype = Object.create(C.prototype);
$f.prototype.constructor = $f;
$f.prototype.h = $f;
$f.l = {};
a.HyperedgeTreeEdge = $f;
$f.prototype.__destroy__ = function() {
  Xc(this.g);
};
function P() {
  this.g = Yc();
  E(P)[this.g] = this;
}
P.prototype = Object.create(C.prototype);
P.prototype.constructor = P;
P.prototype.h = P;
P.l = {};
a.AStarPath = P;
P.prototype.search = P.prototype.search = function(b, c, e, h) {
  var k = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  h && "object" === typeof h && (h = h.g);
  Zc(k, b, c, e, h);
};
P.prototype.__destroy__ = function() {
  $c(this.g);
};
function ag(b, c) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  this.g = void 0 === c ? ad(b) : bd(b, c);
  E(ag)[this.g] = this;
}
ag.prototype = Object.create(C.prototype);
ag.prototype.constructor = ag;
ag.prototype.h = ag;
ag.l = {};
a.ConnEnd = ag;
ag.prototype.__destroy__ = function() {
  cd(this.g);
};
function Q(b, c, e, h) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  h && "object" === typeof h && (h = h.g);
  this.g = void 0 === e ? dd(b, c) : void 0 === h ? ed(b, c, e) : fd(b, c, e, h);
  E(Q)[this.g] = this;
}
Q.prototype = Object.create(C.prototype);
Q.prototype.constructor = Q;
Q.prototype.h = Q;
Q.l = {};
a.ActionInfo = Q;
Q.prototype.obstacle = function() {
  return H(gd(this.g), R);
};
Q.prototype.shape = Q.prototype.shape = function() {
  return H(hd(this.g), S);
};
Q.prototype.conn = function() {
  return H(jd(this.g), T);
};
Q.prototype.junction = function() {
  return H(kd(this.g), U);
};
Q.prototype.addConnEndUpdate = function(b, c, e) {
  var h = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  ld(h, b, c, e);
};
Q.prototype.get_type = Q.prototype.A = function() {
  return md(this.g);
};
Q.prototype.set_type = Q.prototype.M = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  nd(c, b);
};
Object.defineProperty(Q.prototype, "type", {get:Q.prototype.A, set:Q.prototype.M});
Q.prototype.get_objPtr = Q.prototype.ja = function() {
  return H(od(this.g), Xf);
};
Q.prototype.set_objPtr = Q.prototype.Ba = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  pd(c, b);
};
Object.defineProperty(Q.prototype, "objPtr", {get:Q.prototype.ja, set:Q.prototype.Ba});
Q.prototype.get_newPoly = Q.prototype.ga = function() {
  return H(qd(this.g), O);
};
Q.prototype.set_newPoly = Q.prototype.ya = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  rd(c, b);
};
Object.defineProperty(Q.prototype, "newPoly", {get:Q.prototype.ga, set:Q.prototype.ya});
Q.prototype.get_newPosition = Q.prototype.ha = function() {
  return H(sd(this.g), L);
};
Q.prototype.set_newPosition = Q.prototype.za = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  td(c, b);
};
Object.defineProperty(Q.prototype, "newPosition", {get:Q.prototype.ha, set:Q.prototype.za});
Q.prototype.get_firstMove = Q.prototype.ca = function() {
  return !!ud(this.g);
};
Q.prototype.set_firstMove = Q.prototype.ua = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  vd(c, b);
};
Object.defineProperty(Q.prototype, "firstMove", {get:Q.prototype.ca, set:Q.prototype.ua});
Q.prototype.__destroy__ = function() {
  wd(this.g);
};
function V(b, c, e, h, k, l, n) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  h && "object" === typeof h && (h = h.g);
  k && "object" === typeof k && (k = k.g);
  l && "object" === typeof l && (l = l.g);
  n && "object" === typeof n && (n = n.g);
  this.g = void 0 === e ? xd(b, c) : void 0 === h ? yd(b, c, e) : void 0 === k ? _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_4(b, c, e, h) : void 0 === l ? _emscripten_bind_ShapeConnectionPin_ShapeConnectionPin_5(b, c, e, h, k) : void 0 === n ? zd(b, c, e, h, k, l) : Ad(b, c, e, h, k, l, n);
  E(V)[this.g] = this;
}
V.prototype = Object.create(C.prototype);
V.prototype.constructor = V;
V.prototype.h = V;
V.l = {};
a.ShapeConnectionPin = V;
V.prototype.setConnectionCost = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Bd(c, b);
};
V.prototype.position = V.prototype.position = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return void 0 === b ? H(Cd(c), L) : H(Dd(c, b), L);
};
V.prototype.directions = function() {
  return Ed(this.g);
};
V.prototype.setExclusive = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Fd(c, b);
};
V.prototype.isExclusive = function() {
  return !!Gd(this.g);
};
V.prototype.__destroy__ = function() {
  Hd(this.g);
};
function R() {
  throw "cannot construct a Obstacle, no constructor in IDL";
}
R.prototype = Object.create(C.prototype);
R.prototype.constructor = R;
R.prototype.h = R;
R.l = {};
a.Obstacle = R;
R.prototype.id = R.prototype.id = function() {
  return Id(this.g);
};
R.prototype.polygon = function() {
  return H(Jd(this.g), O);
};
R.prototype.router = function() {
  return H(Kd(this.g), W);
};
R.prototype.position = R.prototype.position = function() {
  return H(Ld(this.g), L);
};
R.prototype.__destroy__ = function() {
  Md(this.g);
};
function U(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = void 0 === e ? Nd(b, c) : Od(b, c, e);
  E(U)[this.g] = this;
}
U.prototype = Object.create(C.prototype);
U.prototype.constructor = U;
U.prototype.h = U;
U.l = {};
a.JunctionRef = U;
U.prototype.position = U.prototype.position = function() {
  return H(Pd(this.g), L);
};
U.prototype.__destroy__ = function() {
  Qd(this.g);
};
function S(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = void 0 === e ? Rd(b, c) : Sd(b, c, e);
  E(S)[this.g] = this;
}
S.prototype = Object.create(C.prototype);
S.prototype.constructor = S;
S.prototype.h = S;
S.l = {};
a.ShapeRef = S;
S.prototype.polygon = function() {
  return H(Td(this.g), O);
};
S.prototype.position = S.prototype.position = function() {
  return H(Ud(this.g), L);
};
S.prototype.__destroy__ = function() {
  Vd(this.g);
};
function bg() {
  throw "cannot construct a HyperedgeNewAndDeletedObjectLists, no constructor in IDL";
}
bg.prototype = Object.create(C.prototype);
bg.prototype.constructor = bg;
bg.prototype.h = bg;
bg.l = {};
a.HyperedgeNewAndDeletedObjectLists = bg;
bg.prototype.__destroy__ = function() {
  Wd(this.g);
};
function cg() {
  this.g = Xd();
  E(cg)[this.g] = this;
}
cg.prototype = Object.create(C.prototype);
cg.prototype.constructor = cg;
cg.prototype.h = cg;
cg.l = {};
a.HyperedgeRerouter = cg;
cg.prototype.registerHyperedgeForRerouting = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  return Yd(c, b);
};
cg.prototype.__destroy__ = function() {
  Zd(this.g);
};
function dg() {
  throw "cannot construct a VertInf, no constructor in IDL";
}
dg.prototype = Object.create(C.prototype);
dg.prototype.constructor = dg;
dg.prototype.h = dg;
dg.l = {};
a.VertInf = dg;
dg.prototype.__destroy__ = function() {
  $d(this.g);
};
function X(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = void 0 === b ? ae() : void 0 === c ? _emscripten_bind_VertID_VertID_1(b) : void 0 === e ? be(b, c) : ce(b, c, e);
  E(X)[this.g] = this;
}
X.prototype = Object.create(C.prototype);
X.prototype.constructor = X;
X.prototype.h = X;
X.l = {};
a.VertID = X;
X.prototype.get_objID = X.prototype.ia = function() {
  return de(this.g);
};
X.prototype.set_objID = X.prototype.Aa = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ee(c, b);
};
Object.defineProperty(X.prototype, "objID", {get:X.prototype.ia, set:X.prototype.Aa});
X.prototype.get_vn = X.prototype.J = function() {
  return fe(this.g);
};
X.prototype.set_vn = X.prototype.N = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ge(c, b);
};
Object.defineProperty(X.prototype, "vn", {get:X.prototype.J, set:X.prototype.N});
X.prototype.get_props = X.prototype.ka = function() {
  return he(this.g);
};
X.prototype.set_props = X.prototype.Ca = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ie(c, b);
};
Object.defineProperty(X.prototype, "props", {get:X.prototype.ka, set:X.prototype.Ca});
X.prototype.get_src = X.prototype.ma = function() {
  return je(this.g);
};
Object.defineProperty(X.prototype, "src", {get:X.prototype.ma});
X.prototype.get_tar = X.prototype.na = function() {
  return ke(this.g);
};
Object.defineProperty(X.prototype, "tar", {get:X.prototype.na});
X.prototype.get_PROP_ConnPoint = X.prototype.V = function() {
  return le(this.g);
};
Object.defineProperty(X.prototype, "PROP_ConnPoint", {get:X.prototype.V});
X.prototype.get_PROP_OrthShapeEdge = X.prototype.Y = function() {
  return me(this.g);
};
Object.defineProperty(X.prototype, "PROP_OrthShapeEdge", {get:X.prototype.Y});
X.prototype.get_PROP_ConnectionPin = X.prototype.W = function() {
  return ne(this.g);
};
Object.defineProperty(X.prototype, "PROP_ConnectionPin", {get:X.prototype.W});
X.prototype.get_PROP_ConnCheckpoint = X.prototype.U = function() {
  return oe(this.g);
};
Object.defineProperty(X.prototype, "PROP_ConnCheckpoint", {get:X.prototype.U});
X.prototype.get_PROP_DummyPinHelper = X.prototype.X = function() {
  return pe(this.g);
};
Object.defineProperty(X.prototype, "PROP_DummyPinHelper", {get:X.prototype.X});
X.prototype.__destroy__ = function() {
  qe(this.g);
};
function eg() {
  throw "cannot construct a MinimumTerminalSpanningTree, no constructor in IDL";
}
eg.prototype = Object.create(C.prototype);
eg.prototype.constructor = eg;
eg.prototype.h = eg;
eg.l = {};
a.MinimumTerminalSpanningTree = eg;
eg.prototype.__destroy__ = function() {
  re(this.g);
};
function fg(b) {
  b && "object" === typeof b && (b = b.g);
  this.g = se(b);
  E(fg)[this.g] = this;
}
fg.prototype = Object.create(C.prototype);
fg.prototype.constructor = fg;
fg.prototype.h = fg;
fg.l = {};
a.Checkpoint = fg;
fg.prototype.__destroy__ = function() {
  te(this.g);
};
function T(b, c, e, h) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  h && "object" === typeof h && (h = h.g);
  this.g = void 0 === h ? ue(b, c, e) : ve(b, c, e, h);
  E(T)[this.g] = this;
}
T.prototype = Object.create(C.prototype);
T.prototype.constructor = T;
T.prototype.h = T;
T.l = {};
a.ConnRef = T;
T.prototype.id = T.prototype.id = function() {
  return we(this.g);
};
T.prototype.setCallback = function(b, c) {
  var e = this.g;
  p(b instanceof Function, "Expecting function");
  p("undefined" != typeof b);
  if (!la) {
    la = new WeakMap();
    for (var h = Ca.length, k = 0; k < 0 + h; k++) {
      var l = x(k);
      l && la.set(l, k);
    }
  }
  if (la.has(b)) {
    b = la.get(b);
  } else {
    if (ka.length) {
      h = ka.pop();
    } else {
      try {
        Ca.grow(1);
      } catch (t) {
        if (!(t instanceof RangeError)) {
          throw t;
        }
        throw "Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.";
      }
      h = Ca.length - 1;
    }
    try {
      k = h, Ca.set(k, b), Ya[k] = b;
    } catch (t) {
      if (!(t instanceof TypeError)) {
        throw t;
      }
      p(!0, "Missing signature argument to addFunction: " + b);
      if ("function" == typeof WebAssembly.Function) {
        l = {i:"i32", j:"i64", f:"f32", d:"f64"};
        var n = {parameters:[], results:[]};
        for (k = 1; 2 > k; ++k) {
          n.parameters.push(l["vi"[k]]);
        }
        l = new WebAssembly.Function(n, b);
      } else {
        l = [1, 0, 1, 96,];
        n = {i:127, j:126, f:125, d:124,};
        l.push(1);
        for (k = 0; 1 > k; ++k) {
          l.push(n["i"[k]]);
        }
        l.push(0);
        l[1] = l.length - 2;
        k = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0,].concat(l, [2, 7, 1, 1, 101, 1, 102, 0, 0, 7, 5, 1, 1, 102, 0, 0,]));
        k = new WebAssembly.Module(k);
        l = (new WebAssembly.Instance(k, {e:{f:b}})).exports.f;
      }
      k = h;
      Ca.set(k, l);
      Ya[k] = l;
    }
    la.set(b, h);
    b = h;
  }
  c && "object" === typeof c && (c = c.g);
  xe(e, b, c);
};
T.prototype.setSourceEndpoint = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ye(c, b);
};
T.prototype.setDestEndpoint = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  ze(c, b);
};
T.prototype.routingType = function() {
  return Ae(this.g);
};
T.prototype.setRoutingType = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Be(c, b);
};
T.prototype.displayRoute = function() {
  return H(Ce(this.g), O);
};
T.prototype.setHateCrossings = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  De(c, b);
};
T.prototype.doesHateCrossings = function() {
  return !!Ee(this.g);
};
T.prototype.__destroy__ = function() {
  Fe(this.g);
};
function gg(b, c, e) {
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  this.g = void 0 === e ? Ge(b, c) : He(b, c, e);
  E(gg)[this.g] = this;
}
gg.prototype = Object.create(C.prototype);
gg.prototype.constructor = gg;
gg.prototype.h = gg;
gg.l = {};
a.EdgeInf = gg;
gg.prototype.__destroy__ = function() {
  Ie(this.g);
};
function Y() {
  throw "cannot construct a LineRep, no constructor in IDL";
}
Y.prototype = Object.create(C.prototype);
Y.prototype.constructor = Y;
Y.prototype.h = Y;
Y.l = {};
a.LineRep = Y;
Y.prototype.get_begin = Y.prototype.Z = function() {
  return H(Je(this.g), L);
};
Y.prototype.set_begin = Y.prototype.sa = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Ke(c, b);
};
Object.defineProperty(Y.prototype, "begin", {get:Y.prototype.Z, set:Y.prototype.sa});
Y.prototype.get_end = Y.prototype.ba = function() {
  return H(Le(this.g), L);
};
Y.prototype.set_end = Y.prototype.ta = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Me(c, b);
};
Object.defineProperty(Y.prototype, "end", {get:Y.prototype.ba, set:Y.prototype.ta});
Y.prototype.__destroy__ = function() {
  Ne(this.g);
};
function W(b) {
  b && "object" === typeof b && (b = b.g);
  this.g = Oe(b);
  E(W)[this.g] = this;
}
W.prototype = Object.create(C.prototype);
W.prototype.constructor = W;
W.prototype.h = W;
W.l = {};
a.Router = W;
W.prototype.processTransaction = function() {
  return !!Pe(this.g);
};
W.prototype.printInfo = function() {
  Qe(this.g);
};
W.prototype.deleteConnector = function(b) {
  var c = this.g;
  b && "object" === typeof b && (b = b.g);
  Re(c, b);
};
W.prototype.moveShape = function(b, c, e) {
  var h = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  e && "object" === typeof e && (e = e.g);
  Se(h, b, c, e);
};
W.prototype.setRoutingParameter = function(b, c) {
  var e = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  Te(e, b, c);
};
W.prototype.setRoutingOption = function(b, c) {
  var e = this.g;
  b && "object" === typeof b && (b = b.g);
  c && "object" === typeof c && (c = c.g);
  Ue(e, b, c);
};
W.prototype.__destroy__ = function() {
  Ve(this.g);
};
(function() {
  function b() {
    a.ConnDirNone = We();
    a.ConnDirUp = Xe();
    a.ConnDirDown = Ye();
    a.ConnDirLeft = Ze();
    a.ConnDirRight = $e();
    a.ConnDirAll = af();
    a.ConnEndPoint = bf();
    a.ConnEndShapePin = cf();
    a.ConnEndJunction = df();
    a.ConnEndEmpty = ef();
    a.ShapeMove = ff();
    a.ShapeAdd = gf();
    a.ShapeRemove = hf();
    a.JunctionMove = jf();
    a.JunctionAdd = kf();
    a.JunctionRemove = lf();
    a.ConnChange = mf();
    a.ConnectionPinChange = nf();
    a.TransformationType_CW90 = of();
    a.TransformationType_CW180 = pf();
    a.TransformationType_CW270 = qf();
    a.TransformationType_FlipX = rf();
    a.TransformationType_FlipY = sf();
    a.ConnType_None = tf();
    a.ConnType_PolyLine = uf();
    a.ConnType_Orthogonal = vf();
    a.PolyLineRouting = wf();
    a.OrthogonalRouting = xf();
    a.segmentPenalty = yf();
    a.anglePenalty = zf();
    a.crossingPenalty = Af();
    a.clusterCrossingPenalty = Bf();
    a.fixedSharedPathPenalty = Cf();
    a.portDirectionPenalty = Df();
    a.shapeBufferDistance = Ef();
    a.idealNudgingDistance = Ff();
    a.reverseDirectionPenalty = Gf();
    a.nudgeOrthogonalSegmentsConnectedToShapes = Hf();
    a.improveHyperedgeRoutesMovingJunctions = If();
    a.penaliseOrthogonalSharedPathsAtConnEnds = Jf();
    a.nudgeOrthogonalTouchingColinearSegments = Kf();
    a.performUnifyingNudgingPreprocessingStep = Lf();
    a.improveHyperedgeRoutesMovingAddingAndDeletingJunctions = Mf();
    a.nudgeSharedPathsWithCommonEndPoint = Nf();
  }
  La ? b() : Ja.unshift(b);
})();



  return initAvoidModule.ready
}
);
})();
export default initAvoidModule;